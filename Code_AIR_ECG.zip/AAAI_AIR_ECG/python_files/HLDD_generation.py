import csv
import pandas as pd
import matplotlib. pyplot as plt
import cv2
from skimage.feature import local_binary_pattern
from skimage import data, filters
import numpy as np
import skimage.segmentation
from sklearn.preprocessing import MinMaxScaler
from collections import Counter
import data_generate as datagen
from pathlib import Path
import os
#构造lbp一阶差分，基于原始一阶的二阶差分，基于lbp一阶的lbp二阶差分数据

#一阶差分数据构造
def chafen1(y):
    l = len(y)
    data_LBP = np.zeros(y.shape, dtype=y.dtype)
    for i in range(0, l):
        if (i==0) or (i==l-1):      #对最前面和最后面几个数据先暂时赋值为原来的值
            data_LBP[i]=y[i]
        else:
            center = y[i]
            LBPtemp=y[i+1]-y[i]     #原始的差分数据构造
            # 比中心像素大的点赋值为1，比中心像素小的点赋值为0，然后将这8位二进制数转换成十进制数

            data_LBP[i] = LBPtemp
            print('第', i, data_LBP[i])
    data_LBP[0]=data_LBP[1]         #重新用最近邻的计算的lbp值对最前面和最后面的数据进行赋值
    data_LBP[l-1]=data_LBP[l-2]
    return data_LBP

#基于lbp的一阶差分数据构造
def LBP_chazhi_first(y,step):
    l=len(y)
    data_LBP = np.zeros(y.shape, dtype = y.dtype)
    right_step = range(1, step + 1)
    left_step = [-r1 for r1 in right_step]
    left_step.reverse()
    step_list = list(left_step) + list(right_step)      #利用步长得到局部的序列
    yiwei = range(step * 2)                             #编码的指数变量
    list(yiwei).reverse()

    for i in range(0, l):
        lbp_chazhi_ele = 0
        if (i<=step-1) or (i>=l-step):                  #最前面最后面几个数据的初始赋值
            data_LBP[i]=y[i]
        else:
            center = y[i]
            LBPchazhi =[]

            n = step*2-1                                # 控制移位的变量
            for j in step_list:
                # 比中心像素大的点赋值为1，比中心像素小的点赋值为0，然后将这8位二进制数转换成十进制数
                #LBPtemp |= (y[i+j] >= center) << pow(2,yiwei[n])
                LBPchazhi.append(y[i+j]-center)         #求的局部和中心的点的差值序列
            for lbp_chazhi in LBPchazhi:                #对差值进行一个编码，基数2只是会影响量级
                    lbp_chazhi_ele=lbp_chazhi_ele+lbp_chazhi * pow(2, yiwei[n])
                    n=n-1

        data_LBP[i] = lbp_chazhi_ele
        if i==step:                                     #利用最邻近的lbp对最前面和最后面的lbp进行赋值
            for fir_ele in range(step):
                data_LBP[fir_ele]=lbp_chazhi_ele
        if i==l-step-1:
            for last_ele in range(l-step,l):
                data_LBP[last_ele]=lbp_chazhi_ele
    return data_LBP

def first_second_generate(original_carbon_path,step,chafen1_path_name,lbp1_path_name,lbp2_path_name,fig_path):

    data_name=Path(original_carbon_path).stem
    filenames = os.listdir(original_carbon_path)
    for i, filename in enumerate(filenames):
        data_name = filename.split('.')[0]
        csv_paths=str(original_carbon_path) + str(data_name) + '.csv'
        with open(csv_paths, 'a+', newline='',encoding='UTF-8') as f:
            data_original=pd.read_csv(csv_paths,header=None)
            data_original=np.array(data_original)
        for i in data_original:
            #画原始数据
            X=range(len(i))
            Y=i
            plt.figure(figsize=(24,16))
            plt.subplot(231)
            plt.title('original data')
            plt.plot(X,Y)
            # 一阶差分数据构造
            data_chafen1 = chafen1(Y)
            plt.subplot(232)
            plt.title('chafen1')
            plt.plot(X, data_chafen1)

            # 二阶差分数据构造
            data_chafen2 = chafen1(data_chafen1)
            plt.subplot(233)
            plt.title('chafen2')
            plt.plot(X, data_chafen2)
            # lbp一阶差分数据构造
            data_lbp_diff_first = LBP_chazhi_first(Y, step)
            plt.subplot(235)
            plt.title('FLDD')
            plt.plot(X, data_lbp_diff_first)
            # lbp二阶差分数据构造，在原始一阶数据基础上

            data_lbp_diff_second = LBP_chazhi_first(data_chafen1, step)
            plt.subplot(236)
            plt.title('SLDD')
            plt.plot(X, data_lbp_diff_second)
            # lbp二阶差分数据构造，在lbp一阶数据基础上
            data_lbp_diff_second_lbp1 = LBP_chazhi_first(data_lbp_diff_first, step)
            plt.subplot(234)
            plt.title('lbp_diff_second_lbp1')
            plt.plot(X, data_lbp_diff_second_lbp1)
            plt.savefig(fig_path+'ori_lbp1_chafenlbp2_figs_{}'.format(data_name)+'.png')
            # plt.show()

            #ECG数据差分数据连续写入
            datagen.write_to_csv_union(str(chafen1_path_name) + str(data_name)+'chafen1.csv', data_chafen1)
            datagen.write_to_csv_union(str(lbp1_path_name) + str(data_name)+'FLDD.csv', data_lbp_diff_first)
            datagen.write_to_csv_union(str(lbp2_path_name) + str(data_name)+'SLDD.csv', data_lbp_diff_second)

#5个参数：
# 读取的原始数据路径csv，r'carbon.csv',
# 构造的三条数据的写入csv路径r'carbon_lbp_second_1000.csv'
#   步长2
if __name__ == '__main__':
    # first_second_generate(r'carbon1000.csv',2)
    #计算ECG数据的lbp1，基于差分的lbp2数据
    # first_second_generate(r'ECG/ECG9500_1.csv', 2)
    # 计算ECG数据的lbp1，基于差分的lbp2数据
    # first_second_generate(r'ECG/ECG9500_1_train.csv', 2)
    # first_second_generate(r'carbon10.csv', 2)

    #计算ECG_chdb_chf02_data1的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/chf02_data1/chfdb_chf02_2500_anomaly1_data1.csv', 2)
    # 计算ECG_chdb_chf02_data2的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/chf02_data2/chfdb_chf02_2500_anomaly1_data2.csv', 2)

    # 计算mitdb100_data1的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/mitdb100_data1/mitdb100_3600_anomaly1_data1.csv', 2)
    # 计算mitdb100_data2的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/mitdb100_data2/mitdb100_3600_anomaly1_data2.csv', 2)

    # 计算qtdbsel104_data1的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/qtdbsel104_data1/qtdbsel104_2500_anomaly3_data1.csv', 2)
    # 计算qtdbsel104_data2的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/qtdbsel104_data2/qtdbsel104_2500_anomaly3_data2.csv', 2)

    # 计算qtdbsele0126_data1的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_2500_anomaly1_data1.csv', 2)
    # 计算qtdbsele0126_data2的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/qtdbsel104_data2/qtdbsel104_2500_anomaly3_data2.csv', 2)

    # 计算mitdb102_data1的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/mitdb102_data1/mitdb102_3600_anomaly1_data1.csv', 2)

    # 计算mitdb104_data1的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/mitdb104_data1/mitdb104_3600_anomaly4_data1.csv', 2)

    # 计算mitdb104_data2的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/mitdb104_data2/mitdb104_3600_anomaly4_data2.csv', 2)

    # 计算chfdb01_275_data1的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/chf01_275_data1/chfdb01_275_3751_anomaly1_data1.csv', 2)

    # 计算chfdb01_275_data2的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/chf01_275_data2/chfdb01_275_3751_anomaly1_data2.csv', 2)

    # 计算chf13_3750_data1的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_3750_anomaly1_data1.csv', 2)

    # # 计算chf13_3750_data2的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_3750_anomaly1_data2.csv', 2)

    # # 计算mitdb100_108_data1的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_anomaly1_data1.csv', 2)

    # 计算mitdbx108_x108_data1的两种类型的数据
    # first_second_generate(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_anomaly1_data1.csv', 2)

    # 计算mitdbx108_x108_data2的两种类型的数据
    # first_second_generate(
    #     r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_anomaly1_data2.csv', 2)

    # # 计算qtdb102_15000_data1的两种类型的数据
    # first_second_generate(
    #     r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_anomaly1_data1.csv', 2)

    # # 计算qtdb0606_1500_data2的两种类型的数据
    # first_second_generate(
    #     r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_anomaly1_data2.csv', 2)

    # 计算chf15_3000_data1的两种类型的数据
    # first_second_generate(
    #     r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chfdb15_3000_anomaly1_data1.csv', 2)

    # 计算chf15_3000_data2的两种类型的数据
    # first_second_generate(
    #     r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chfdb15_3000_anomaly1_data2.csv', 2)

    # 计算Space Shuttle dataset data1的两种类型的数据
    # first_second_generate(
    #     r'video_sur_dataset/video_sur_data1/video_sur_2000_anomaly_data1.csv', 2)

    # 计算Space Shuttle dataset data2的两种类型的数据
    # first_second_generate(
    #     r'video_sur_dataset/video_sur_data2/video_sur_3000_anomaly_data2.csv', 2)

    # 计算space_shuttle dataset data1的两种类型的数据
    # first_second_generate(
    #     r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_tek16_5000_anomaly.csv', 2)

    # 计算powerdemand dataset data1的两种类型的数据
    # first_second_generate(
    #     r'power_demand\power_demand_data\power_demand_5000_anomaly_data1.csv', 2)

    # 计算respiration44 dataset data1的两种类型的数据
    # first_second_generate(
    #     r'respiration_dataset\respiration_data44\respiration6500_anomaly_data1.csv', 2)

    # #***************************合成数据测试******************************
    # first_second_generate(
    #     r'comparsion_methods/compare_files/artificial_dataset/artificial_datasets.csv', 2)

    #碳星画图用
    # first_second_generate(
    #     r'carbon_test/spec-55862-B6210_sp08-188.csv', 2)

# ***************************188碳星数据测试******************************
    #提供原始数据和三个写入文件的路径
    # ori_path=r'carbon_test/spec-55862-B6210_sp08-188.csv'
    # data_name=ori_path.split('/')[1].split('.')[0]
    # chafen1_path=r'carbon_union_files/carbon_union_chafenlbp12/'+str(data_name)+'_chafen1.csv'
    # lbp1_path=r'carbon_union_files/carbon_union_chafenlbp12/'+str(data_name)+'_lbp1.csv'
    # lbp2_path=r'carbon_union_files/carbon_union_chafenlbp12/'+str(data_name)+'_chafenlbp2.csv'
    # lbp_step=2

    # first_second_generate(
    #    ori_path, lbp_step,chafen1_path,lbp1_path,lbp2_path)

    carbon_csv_path_read = r'../results/carboncsv100/'
    carbonchafen1_100 = r'../results/carbonchafen1_100'
    step = 2
    carbonFLDD_path = r'../results/carbonFLDD100'
    carbonSLDD_path = r'../results/carbonSLDD100'
    fig_SLDD_path = r'../results/figs_chafen_FLDD_SLDD'
    first_second_generate(carbon_csv_path_read,step,carbonchafen1_100,carbonFLDD_path,carbonSLDD_path,fig_SLDD_path)
