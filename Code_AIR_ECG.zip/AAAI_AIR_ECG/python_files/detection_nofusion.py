import csv
import datetime
import os

import interval_fusion
import portion as P
import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt
# 归一化
def MMS(data):
    length=len(data)
    weights=[]
    for i in range(length):
        weights.append(float(data[i]/np.sum(data)))
    return weights

def interval_simi(filename):
    interval_floats=interval_fusion.read_interval(filename)   #读区间，转为float
    for oneline_interval in interval_floats:   #oneline_interval 一条数据的区间们
        interval_num = len(oneline_interval)  # 一条数据的区间数
        all_interval_simi=[]
        for i in range(interval_num):  # 对于每个区间，计算不相似度
            dis_similar = 0
            certain_interval_dissimilar=0
            for j in range(interval_num):

                interval_inter = P.closed(oneline_interval[i][0], oneline_interval[i][1]) & P.closed(oneline_interval[j][0], oneline_interval[j][1])
                interval_union = P.closed(oneline_interval[i][0], oneline_interval[i][1]) | P.closed(oneline_interval[j][0], oneline_interval[j][1])
                # 两两区间计算不相似度和
                # print('看看交集到底是什么样子的空',interval_inter)
                if len(interval_inter) == 0:  # 没有交集的时候利用，相距的差值来代表不相似度
                        dis_similar = dis_similar + 1

                        continue
                else:
                    if interval_inter.upper - interval_inter.lower == 0:  # 如果交集为0，做除数的情况
                        dis_similar = dis_similar + 1

                        continue

                dis_similar = dis_similar + 1 - np.abs((interval_inter.upper - interval_inter.lower)) / np.abs(
                    (interval_union.upper - interval_union.lower))

            # 求平均的不相似度作为 该段的整体不相似程度certain_interval_dissimilar
            if interval_num == 1:  # 如果只有一条数据，无法计算数据之间的相似
                certain_interval_dissimilar = 1
            else:
                certain_interval_dissimilar = dis_similar / interval_num
            all_interval_simi.append(certain_interval_dissimilar)
            # print('看看不相似度是多少', certain_interval_dissimilar)
    all_interval_simi=MMS(all_interval_simi)
    # print('看看归一化后的不相似度是多少', all_interval_simi)
    return all_interval_simi

def detection_nofusion(ori_sim,lbp1_sim,chafenlbp2_sim,filename_label,n,ECGresults_filename,ori_filename,interval_size,start_time,clu_num):
    interval_len=len(ori_sim)
    simi=[p+q+m for p,q,m in zip(ori_sim,lbp1_sim,chafenlbp2_sim)]  #三种数据融合
    print('最终不相似度',simi)
    simi=np.asarray(simi)
    plt.bar(range(len(simi)),simi)
    plt.show()
    top_index=simi.argsort()[-n:][::-1]     #检测前n个
    print('检测出的异常段索引',top_index)
    print('检测出的异常段分数',simi[top_index])
    alldata_label=[]
    with open(filename_label,'r+',newline='') as f: #计算AR和CI
        f.seek(0)
        labels_string=f.readlines()
        for label_string in labels_string:
            label_float=[float(label) for label in label_string.split(',')]
            alldata_label.append(label_float)
        count=0
        anomaly_right_simi=0
        for index in top_index:
            if alldata_label[0][index]==-1:
                count=count+1
                anomaly_right_simi=anomaly_right_simi+simi[index]
        index_anomal=0
        anomal_index=[x for (x,y) in enumerate(alldata_label[0]) if y==-1 ]
        anomaly_all_simi=np.average(simi[anomal_index])
        print('真实异常段为',anomal_index)
        AR=count/n
        CI=anomaly_all_simi/np.average(simi)
        print('CI=',CI)

        #计算时间
        endtime = datetime.datetime.now()
        print('结束时间',endtime)
        time_consume = (endtime - start_time).total_seconds()
        print('时间差=',time_consume)
        path_str=Path(filename_label)
        path_nofusion=path_str.parent.joinpath("nofusion")
        with open(ori_filename,'a+',newline='') as f_draw:
            f_draw.seek(0)
            data_str=f_draw.readlines()
            data_float=[float(data)for data in data_str[0].split(',')]
            interval_num=int(len(data_float)/interval_size)
            results_name_path=Path(ori_filename).stem
            for i in range(interval_num):
                if i in top_index:
                    plt.plot(range(i*interval_size,(i+1)*interval_size),data_float[i*interval_size:(i+1)*interval_size],'r')
                    plt.savefig(os.path.join(os.path.abspath(
                        r'../results/detection_results_figs'),
                                              results_name_path + 'size{}'.format(
                                                  interval_size) + 'detectnofusion.png'))
                    # print(os.path.join(os.path.abspath(
                    #     r'D:\zlc\pycharm_projects\pythonProject\ECGlianxvceshi\ECG100200_resultfigs'),
                    #                           results_name_path + 'size{}'.format(
                    #                               interval_size) + 'detectnofusion.png'))

                else:
                    plt.plot(range(i*interval_size,(i+1)*interval_size),data_float[i*interval_size:(i+1)*interval_size],'k')
                    plt.savefig((os.path.join(os.path.abspath(r'../results/detection_results_figs'),
                         results_name_path + 'size{}'.format(interval_size) + 'detectnofusion.png')))
            # plt.show()
        data_name=ori_filename.split('/')[-1]
        with open(ECGresults_filename,'a+',newline='') as f_write:
            write=csv.writer(f_write)

            results=[path_nofusion,data_name,interval_size,AR,top_index,CI,anomal_index,start_time,endtime,time_consume,clu_num,simi]
            write.writerow(results)







if __name__=='__main__':
    #8个参数：三个路径参数,一个区间标签路径，一个要检测的异常段数,段长，写入的结果文件路径,原始数据路径（画图用）

    #mitdb100_data1  三类数据各自不相似，进制融合
    # ori_simi=interval_simi(r'ECG/ECG_datasets/mitdb100_data1/mitdb100_oridata1_interval1_300.csv')
    # lbp1_simi=interval_simi(r'ECG/ECG_datasets/mitdb100_data1/mitdb100_lbp1data1_interval1_300.csv')
    # chafenlbp2_simi=interval_simi(r'ECG/ECG_datasets/mitdb100_data1/mitdb100_chafenlbp2data1_interval1_300.csv')
    #
    # label_filename = r'ECG/ECG_datasets/new_prese/mitdb100_data1/mitdb100_intervallabel300.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/mitdb100_data1/mitdb100_3600_anomaly1_data1.csv'
    # detect_num = 2
    # interval_size = 300
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # mitdb100_data2  三类数据各自不相似，进制融合
    # ori_simi=interval_simi(r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_oridata2_interval1_320.csv')
    # lbp1_simi=interval_simi(r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_lbp1data2_interval1_320.csv')
    # chafenlbp2_simi=interval_simi(r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_chafenlbp2data2_interval1_320.csv')
    # label_filename = r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_intervallabel320.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_3600_anomaly1_data2.csv'
    # detect_num = 2
    # interval_size = 320
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    #chf02_data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb02_oridata1_interval1_160.csv')
    # lbp1_simi = interval_simi(r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb02_lbp1data1_interval1_160.csv')
    # chafenlbp2_simi = interval_simi(r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb02_chafenlbp2data1_interval1_160.csv')
    #
    # label_filename = r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb_chf02_intervallabel160.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb_chf02_2500_anomaly1_data1.csv'
    # detect_num = 2
    # interval_size = 160
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # chf02_data2 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb02_oridata2_interval1_160.csv')
    # lbp1_simi = interval_simi(r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb02_lbp1data2_interval1_160.csv')
    # chafenlbp2_simi = interval_simi(r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb02_chafenlbp2data2_interval1_160.csv')
    # label_filename=r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb_chf02_intervallabel160.csv'
    #
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # oridata_filename=r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb_chf02_2500_anomaly1_data2.csv'
    # detect_num=2
    # interval_size=160
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,oridata_filename,interval_size)

    # ECG950train 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(r'ECG/ECG9500_interval1_95_train.csv')
    # lbp1_simi = interval_simi(r'ECG/ECG9500_lbp1_interval1_95_train.csv')
    # chafenlbp2_simi = interval_simi(r'ECG/ECG9500_chafen1lbp2_interval1_95_train.csv')

    #qtdbsel104_data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_oridata1_interval3_210.csv')
    # lbp1_simi = interval_simi(r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_lbp1data1_interval3_210.csv')
    # chafenlbp2_simi = interval_simi(r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_chafenlbp2data1_interval3_210.csv')
    #
    # label_filename = r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_intervallabel210.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_2500_anomaly3_data1.csv'
    # detect_num = 2
    # interval_size = 210
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # qtdbsel104_data2 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_oridata2_interval3_210.csv')
    # lbp1_simi = interval_simi(r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_lbp1data2_interval3_210.csv')
    # chafenlbp2_simi = interval_simi(r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_chafenlbp2data2_interval3_210.csv')
    #
    # label_filename = r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_intervallabel210.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_2500_anomaly3_data1.csv'
    # detect_num = 2
    # interval_size = 210
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # qtdbsele0126_data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_oridata1_interval1_200.csv')
    # lbp1_simi = interval_simi(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_lbp1data1_interval1_200.csv')
    # chafenlbp2_simi = interval_simi(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_chafenlbp2data1_interval1_200.csv')
    # label_filename=r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_intervallabel.csv'
    #
    # ECG_results_file=r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi,lbp1_simi,chafenlbp2_simi,label_filename,2,ECG_results_file)

    # mitdb102_data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(r'ECG/ECG_datasets/mitdb102_data1/mitdb102_oridata1_interval1_300.csv')
    # lbp1_simi = interval_simi(r'ECG/ECG_datasets/mitdb102_data1/mitdb102_lbp1data1_interval1_300.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'ECG/ECG_datasets/mitdb102_data1/mitdb102_chafenlbp2data1_interval1_300.csv')
    # label_filename = r'ECG/ECG_datasets/mitdb102_data1/mitdb102_intervallabel.csv'
    #
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, 2, ECG_results_file)

    # mitdb104_data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_oridata1_interval4_300.csv')
    # lbp1_simi = interval_simi(r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_lbp1data1_interval4_300.csv')
    # chafenlbp2_simi = interval_simi(r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_chafenlbp2data1_interval4_300.csv')
    # label_filename = r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_intervallabel300.csv'
    #
    # #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_3600_anomaly4_data1.csv'
    # detect_num = 1
    # interval_size = 300
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # mitdb104_data2 三类数据各自不相似，进制融合
    # starttime = datetime.datetime.now()
    # ori_simi = interval_simi(r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_oridata2_interval4_300.csv')
    # lbp1_simi = interval_simi(r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_lbp1data2_interval4_300.csv')
    # chafenlbp2_simi = interval_simi(r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_chafenlbp2data2_interval4_300.csv')
    # label_filename = r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_intervallabel300.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_3600_anomaly4_data2.csv'
    # detect_num = 2
    # interval_size = 300
    # clu_num = 3
    #
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size,starttime,clu_num)
    # # chf01_275_data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(r'ECG/ECG_datasets/new_prese/chf01_275_data1/chfdb01_275_oridata1_interval2_250.csv')
    # lbp1_simi = interval_simi(r'ECG/ECG_datasets/new_prese/chf01_275_data1/chfdb01_275_lbp1data1_interval2_250.csv')
    # chafenlbp2_simi = interval_simi(r'ECG/ECG_datasets/new_prese/chf01_275_data1/chfdb01_275_chafenlbp2_interval2_250.csv')
    # label_filename = r'ECG/ECG_datasets/new_prese/chf01_275_data1/chf01_275_intervallabel250.csv'
    #
    # oridata_filename=r'ECG/ECG_datasets/new_prese/chf01_275_data1/chfdb01_275_3751_anomaly1_data1.csv'
    # detect_num=1
    # interval_size=250
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,oridata_filename,interval_size)

    # chf01_275_data2 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(r'ECG/ECG_datasets/new_prese/chf01_275_data2/chfdb01_275_oridata2_interval2_450.csv')
    # lbp1_simi = interval_simi(r'ECG/ECG_datasets/new_prese/chf01_275_data2/chfdb01_275_lbp1data2_interval2_450.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/chf01_275_data2/chfdb01_275_chafenlbp2_interval2_450.csv')
    # label_filename = r'ECG/ECG_datasets/new_prese/chf01_275_data2/chf01_275_intervallabel450.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/chf01_275_data2/chfdb01_275_3751_anomaly1_data2.csv'
    # detect_num = 1
    # interval_size = 450
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # chf13_3750_data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_oridata1_interval1_300.csv')
    # lbp1_simi = interval_simi(r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_3750_lbp1data1_interval1_300.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_3750_chafenlbp2_interval1_300.csv')
    # label_filename = r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_3750_intervallabel300.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_3750_anomaly1_data1.csv'
    # detect_num = 1
    # interval_size = 300
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # chf13_3750_data2 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_oridata2_interval1_150.csv')
    # lbp1_simi = interval_simi(r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_3750_lbp1data2_interval1_150.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_3750_chafenlbp2_interval1_150.csv')
    # label_filename = r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_3750_intervallabel150.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_3750_anomaly1_data2.csv'
    # detect_num = 1
    # interval_size = 150
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # mitdb100_108 data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_oridata1_interval1_305.csv')
    # lbp1_simi = interval_simi(r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_lbp1data1_interval1_305.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_chafenlbp2_interval1_305.csv')
    # label_filename = r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_intervallabel305.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_anomaly1_data1.csv'
    # detect_num = 2
    # interval_size = 305
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)
    # # mitdb_x108 data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_oridata1_interval1_600.csv')
    # lbp1_simi = interval_simi(r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_lbp1data1_interval1_600.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_chafenlbp2_interval1_600.csv')
    # label_filename = r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_intervallabel600.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_anomaly1_data1.csv'
    # detect_num = 1
    # interval_size = 600
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # mitdbx108_x108_15000 data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_oridata1_interval1_600.csv')
    # lbp1_simi = interval_simi(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_lbp1data1_interval1_600.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_chafenlbp2_interval1_600.csv')
    # label_filename = r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_intervallabel600.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_anomaly1_data1.csv'
    # detect_num = 5
    # interval_size = 600
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)
    # # mitdbx108_x108_15000 data2 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_oridata2_interval1_600.csv')
    # lbp1_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_lbp1data2_interval1_600.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_chafenlbp2_interval1_600.csv')
    # label_filename = r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_intervallabel600.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_anomaly1_data2.csv'
    # detect_num = 5
    # interval_size = 600
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # qtdbsel102_15000 data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_oridata1_interval1_800.csv')
    # lbp1_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_lbp1data1_interval1_800.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_chafenlbp2_interval1_800.csv')
    # label_filename = r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_intervallabel800.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_anomaly1_data1.csv'
    # detect_num = 1
    # interval_size = 800
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # qtdbsele0606_1500 data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_oridata1_interval1_150.csv')
    # lbp1_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_lbp1data1_interval1_150.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_chafenlbp2_interval1_150.csv')
    # label_filename = r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_intervallabel150.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_anomaly1_data1.csv'
    # detect_num = 1
    # interval_size = 150
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # qtdbsele0606_1500 data2 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_oridata2_interval1_150.csv')
    # lbp1_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_lbp1data2_interval1_150.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_chafenlbp2_interval1_150.csv')
    # label_filename = r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_intervallabel150.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_anomaly1_data2.csv'
    # detect_num = 2
    # interval_size = 150
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # chf15_3000 data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chfdb15_3000_oridata1_interval1_160.csv')
    # lbp1_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chfdb15_3000_lbp1data1_interval1_160.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chf15_3000_chafenlbp2_interval1_160.csv')
    # label_filename = r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chf15_3000_intervallabel160.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chfdb15_3000_anomaly1_data1.csv'
    # detect_num = 2
    # interval_size = 160
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # chf15_3000 data2 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chfdb15_3000_oridata2_interval1_160.csv')
    # lbp1_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chfdb15_3000_lbp1data2_interval1_160.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chf15_3000_chafenlbp2_interval1_160.csv')
    # label_filename = r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chf15_3000_intervallabel160.csv'
    #
    # oridata_filename = r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chfdb15_3000_anomaly1_data2.csv'
    # detect_num = 1
    # interval_size = 160
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # video_sur dataset data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(
    #     r'video_sur_dataset/video_sur_data1/video_sur_2000_oridata1_interval1_150.csv')
    # lbp1_simi = interval_simi(
    #     r'video_sur_dataset/video_sur_data1/video_sur_2000_lbp1data1_interval1_150.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'video_sur_dataset/video_sur_data1/video_sur_2000_chafenlbp2_interval1_150.csv')
    # label_filename = r'video_sur_dataset/video_sur_data1/video_sur_2000_intervallabel150.csv'
    #
    # oridata_filename = r'video_sur_dataset/video_sur_data1/video_sur_2000_anomaly_data1.csv'
    # detect_num = 2
    # interval_size =150
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    #video_sur dataset data2 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(
    #     r'video_sur_dataset/video_sur_data2/video_sur_3000_oridata2_interval1_150.csv')
    # lbp1_simi = interval_simi(
    #     r'video_sur_dataset/video_sur_data2/video_sur_3000_lbp1data2_interval1_150.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'video_sur_dataset/video_sur_data2/video_sur_3000_chafenlbp2_interval1_150.csv')
    # label_filename = r'video_sur_dataset/video_sur_data2/video_sur_3000_intervallabel150.csv'
    #
    # oridata_filename = r'video_sur_dataset/video_sur_data2/video_sur_3000_anomaly_data2.csv'
    # detect_num = 6
    # interval_size = 150
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # # space_shuttle dataset data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(
    #     r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_5000_oridata1_interval1_1000.csv')
    # lbp1_simi = interval_simi(
    #     r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_5000_lbp1data1_interval1_1000.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_5000_chafenlbp2_interval1_1000.csv')
    # label_filename = r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_5000_intervallabel1000.csv'
    #
    # oridata_filename = r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_tek16_5000_anomaly.csv'
    # detect_num = 1
    # interval_size = 1000
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # powerdemand dataset data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(
    #     r'power_demand/power_demand_data/power_demand_5000_oridata1_interval1_690.csv')
    # lbp1_simi = interval_simi(
    #     r'power_demand/power_demand_data/power_demand_5000_lbp1data1_interval1_690.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'power_demand/power_demand_data/power_demand_5000_chafenlbp2_interval1_690.csv')
    # label_filename = r'power_demand/power_demand_data/power_demand_5000_intervallabel690.csv'
    #
    # oridata_filename = r'power_demand/power_demand_data/power_demand_5000_anomaly_data1.csv'
    # detect_num = 3
    # interval_size = 690
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)

    # respiration dataset data1 三类数据各自不相似，进制融合
    # ori_simi = interval_simi(
    #     r'respiration_dataset/respiration_data44/respiration6500_oridata1_interval1_400.csv')
    # lbp1_simi = interval_simi(
    #     r'respiration_dataset/respiration_data44/respiration6500_lbp1data1_interval1_400.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'respiration_dataset/respiration_data44/respiration6500_chafenlbp2_interval1_400.csv')
    # label_filename = r'respiration_dataset/respiration_data44/respiration6500_intervallabel400.csv'
    #
    # oridata_filename = r'respiration_dataset/respiration_data44/respiration6500_anomaly_data1.csv'
    # detect_num = 3
    # interval_size = 400
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)



#*****************合成数据集测试##############################
    # 三类数据各自不相似，进制融合
    # starttime=datetime.datetime.now()
    # ori_simi = interval_simi(
    #     r'comparsion_methods/compare_files/artificial_dataset/artificial_oridata1_interval1_60.csv')
    # lbp1_simi = interval_simi(
    #     r'comparsion_methods/compare_files/artificial_dataset/artificial_lbp1data1_interval1_60.csv')
    # chafenlbp2_simi = interval_simi(
    #     r'comparsion_methods/compare_files/artificial_dataset/artificial_chafenlbp2_interval1_60.csv')
    # label_filename = r'comparsion_methods/compare_files/artificial_dataset/artificial_intervallabel60.csv'
    #
    # oridata_filename = r'comparsion_methods/compare_files/artificial_dataset/artificial_datasets.csv'
    # detect_num = 2
    # interval_size = 60
    # clu_num=3
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size,starttime,clu_num)

    # *****************188碳星数据集测试##############################
    # 三类数据各自不相似，进制融合
    starttime = datetime.datetime.now()
    ori_simi = interval_simi(
        r'carbon_test/spec-55862-B6210_sp08-188_oridata1_interval1_210.csv')
    lbp1_simi = interval_simi(
        r'carbon_test/spec-55862-B6210_sp08-188_lbp1data1_interval1_210.csv')
    chafenlbp2_simi = interval_simi(
        r'carbon_test/spec-55862-B6210_sp08-188_chafenlbp2_interval1_210.csv')
    label_filename = r'carbon_test/spec-55862-B6210_sp08-188_intervallabel210.csv'

    oridata_filename = r'carbon_test/spec-55862-B6210_sp08-188.csv'
    detect_num = 7
    clu_num = 3
    interval_size = 210
    ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
                       oridata_filename, interval_size,starttime,clu_num)

    # *****************再次测试数据集##############################
    # 三类数据各自不相似，进制融合
    # detect_num = 14
    # interval_size = 240
    # oridata_filename = 'carbon_union_files/carbon_union_csv/spec-55903-B90306_sp07-229.csv'
    #
    # ECG_results_file = r'ECG/ECG_datasets/ECG_results_AR_index_reallabel_CI.csv'
    #
    # interval_root='carbon_union_files/carbon_union_intervals/'
    #
    # headroot = oridata_filename.split(".")[0].split('/')[-1]
    # oriroot =interval_root+headroot+'_'+str(interval_size)+"ori_interval" +".csv"
    # lbproot =interval_root+headroot+'_'+str(interval_size)+"lbp1_interval"+".csv"
    # chafenlbp2root = interval_root+headroot+'_'+str(interval_size)+"lbp2_interval"+".csv"
    # labelroot = interval_root+'carbon_common_'+str(interval_size)+"_labelinterval"+".csv"
    #
    # ori_simi = interval_simi(oriroot)
    # lbp1_simi = interval_simi(lbproot)
    # chafenlbp2_simi = interval_simi(chafenlbp2root)
    # label_filename = labelroot
    # detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, detect_num, ECG_results_file,
    #                    oridata_filename, interval_size)


