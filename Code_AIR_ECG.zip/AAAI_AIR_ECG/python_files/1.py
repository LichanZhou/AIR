carbon_csv_path_read= r'D:/zlc/pycharm_projects/2carbon_interval/data/carboncsv100/'
with open(carbon_csv_path_read,'a+',newline='') as f:
    print('查看是否正确')