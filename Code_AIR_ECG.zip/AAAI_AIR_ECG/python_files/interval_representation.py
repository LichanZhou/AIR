import csv
import operator
import numpy as np
from scipy.optimize import minimize,differential_evolution
import matplotlib.pyplot as plt
import math
import time
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import pairwise_distances_argmin
from sklearn.datasets._samples_generator import make_blobs
from sklearn.preprocessing import MinMaxScaler
from scipy.optimize import Bounds

import compare_origin_interval as com_inter
#将数据进行区间表示
#画出原始数据
def plot_origin_interval(data_orig):
    # with open(filename, 'a+', newline='') as f:
    #     f.seek(0)
    #     data_csv = f.readlines()
    #     for data in data_csv:
    data_oneline_float=[]
    for data_origin in data_orig:
        data_oneline_float.append(float(data_origin))

    plt.plot(data_oneline_float)
            # plt.vlines(x1,ymin,ymax, colors='r')

# x_a = np.asarray(0) #优化目标函数的自变量初始值
# x_b = np.asarray(0)
def con(args):
    # 约束条件 分为eq 和ineq
    # eq表示 函数结果等于0 ； ineq 表示 表达式大于等于0
    xmin1, xmax1 = args    #约束条件为：区间的上界b位于中值和最大值之间；下界a位于最小值和中值之间
    cons = ({'type': 'ineq', 'fun': lambda x: x - xmin1},\
            {'type': 'ineq', 'fun': lambda x: -x + xmax1})
    return cons
#求区间的下界a
def one_interval_generation_Va(x_a,data_origin_reduct,u):
    data_median=np.median(data_origin_reduct)   #利用区间的中值，求目标函数的最小值
    data_origin_reduct=np.array(data_origin_reduct)
#中值下标代表覆盖率：数目；区间长度代表特异性：绝对值
    median_index=np.sum(np.where((data_origin_reduct>=x_a)&(data_origin_reduct<data_median),1,0))
    V_a=-u*median_index * math.exp(-(1-u)*np.abs(data_median - x_a))   #最小值函数所以在最前面加个-，求最大值

    # V_a = -median_index * math.exp(-0.5*np.abs(data_median - x_a))
    return V_a
#求区间的上界b
def one_interval_generation_Vb(x_b,data_origin_reduct,u):
    data_median=np.median(data_origin_reduct)
    data_origin_reduct = np.array(data_origin_reduct)
    median_index = np.sum(np.where((data_origin_reduct > data_median) & (data_origin_reduct <= x_b), 1, 0))
    V_b=-u*median_index*math.exp(-(1-u)*np.abs(x_b-data_median))
    # V_b = -median_index * math.exp(-0.5*np.abs(x_b-data_median))
    return V_b

def interval_sets_representation(filename,fix_interval_length,cluster_num):
    with open(filename,'a+',newline='') as f:
        f.seek(0)
        data=f.readlines()
        interval_sets=[]
        for data_line in data:  #对于csv中的每一条数据
            data_line = data_line.split(',')
            if (len(data_line) % fix_interval_length) == 0:
                duan_num = range(len(data_line) // fix_interval_length)  # 初始划分的时候一共有多少段
            else:
                # duan_num = range(len(data_line) // fix_interval_length + 1)
                duan_num = range(int(len(data_line) / fix_interval_length))
            # plot_origin_interval(data_line)
            u = []  # 计算簇内距离
            u = com_inter.calc_cluster_avedis(data_line,fix_interval_length,cluster_num)
            one_interval_sets=[]
            for i in duan_num:           #对于每一个固定段，信息粒化

                a=i*fix_interval_length   #开始固定段的起始和结束位置
                b=(i+1)*fix_interval_length-1
                median_a_b=(a+b)/2
                data_origin_reduct=data_line[a:b+1] #截取每段的数据
                duan_len=len(data_origin_reduct)   #判断是否为最后一段，并用最后的数据进行补足
                # if duan_len<fix_interval_length:
                #     for j in range(fix_interval_length-duan_len):
                #         data_origin_reduct.append(data_origin_reduct[-1])
                data_origin_reduct=list(map(float,data_origin_reduct))

                print(data_origin_reduct)
                xmin=np.min(data_origin_reduct)   #每一段的最大值最小值和中值用来优化函数中的约束条件
                xmax=np.max(data_origin_reduct)
                xmedian=np.median(data_origin_reduct)
                print('最大值',xmax)
                print('中值',xmedian)
                print('最小值',xmin)               #固定段的初始划分线
                # plt.vlines(b, xmin, xmax, color='b', linestyle='--')


                #print('样本平均距离',u)
                # 设置参数范围/约束条件
                args1 = (xmin,xmedian)  # x1min, x1max,
                args2=(xmedian,xmax)
                cons1 = con(args1)
                cons2=con(args2)
                #优化目标函数，求得上下界
                a1=differential_evolution(one_interval_generation_Va, x0=np.asarray(xmedian),args=(data_origin_reduct,u[i]),bounds=[(xmin-0.00001,xmedian+0.00001)]).x
                a1=float(a1)
                print('第',i,'段a=',a1)
                b1=differential_evolution(one_interval_generation_Vb, x0=np.asarray(xmedian), args=(data_origin_reduct,u[i]),bounds=[(xmedian-0.00001,xmax+0.00001)]).x
                b1=float(b1)
                print('b=',b1)
                #画出区间的范围
                plt.vlines(median_a_b, a1, b1, colors='r')
                one_interval_sets.append([a1,b1])
            plt.savefig('')
            plt.show()
            interval_sets.append(one_interval_sets)
            print('第', len(interval_sets), '数据的区间表示')

        return interval_sets
def write_data_interval_csv(filename,interval_sets):
    interval_sets_inner=interval_sets
    with open(filename,'a+',newline='') as f:
        f.seek(0)
        count=0
        data_csv = f.readlines()
        for data_interval in interval_sets_inner:
            ceshi=[str(data_inter) for data_inter in data_interval]
            if data_csv != []:   #判断是否重复写入等条件
                for i in data_csv:
                    j=i.strip('"').split('","')
                    j2=[j1.strip().strip('"') for j1 in j] #转换列表中的格式，使得可以进行比较
                    p=operator.eq(ceshi,j2)
                    if operator.eq(ceshi,j2):
                        print("This data has existed, not write into csv, pass")
                        break;
                    else:
                        writer = csv.writer(f)
                        writer.writerow(data_interval)
                        count = count + 1
                        break;
            else:
                writer = csv.writer(f)
                writer.writerow(data_interval)
                count = count + 1
        print("write", count, "new data")
#构造针对区间的标签
def ECG_interval_label_generatecsv(filename_orilabel,interval_length,filename_intervallabel):
    with open(filename_orilabel,'a+',newline='') as label_f:
        label_f.seek(0)
        interval_label=[]
        labels=label_f.readlines()
        for label in labels:  #一条数据的标签
            label_float=[]
            oneline_label=[]
            for i in label.split(','):  #一行标签转为float
                label_float.append(float(i))
            if len(label_float) // interval_length == 0:  # 区间数interval_num
                interval_num_label = len(label_float) // interval_length
            else:
                interval_num_label = int(len(label_float)/ interval_length)
            for j in range(interval_num_label): #生成对应的区间标签
                if -1 in label_float[j*interval_length:(j+1)*interval_length]:
                    oneline_label.append(-1)
                else:
                    oneline_label.append(1)
            interval_label.append(oneline_label)
        with open(filename_intervallabel,'a+',newline='') as f1:
            writer = csv.writer(f1)
            for p in interval_label:
                writer.writerow(p)




if __name__=='__main__':
    #需要修改的：区间长度，每段的聚类数,区间表示的参数α还是u，4个数值型数据的路径，4个构造的区间数据的路径,2个标签路径
    #区间长度为500，csv文件划分区间段
    interval_len=400
    cluster_num=3  #kmeans_hand.py观察所得，随区间大小改变而改
    # data_interval = interval_sets_representation(r'carbon10.csv', interval_len)
    # write_data_interval_csv(r'carbon1_interval.csv', data_interval)
    # data_interval=interval_sets_representation(r'0_carbon1000.csv',interval_len)
    # write_data_interval_csv(r'0_carbon_interval1000.csv',data_interval)
    # data_interval = interval_sets_representation(r'3_carbon_lbp_first_1000.csv', interval_len)
    # write_data_interval_csv(r'3_carbon_lbp_first_interval1000.csv', data_interval)
    # data_interval = interval_sets_representation(r'4_carbon_lbp_second_1000.csv', interval_len)
    # write_data_interval_csv(r'4_carbon_lbp_second_interval1000.csv', data_interval)
    # data_interval = interval_sets_representation(r'5_carbon_chafen1_lbp_second_1000.csv', interval_len)
    # write_data_interval_csv(r'5_carbon_chafen1_lbp_second_interval1000.csv', data_interval)
    # data_interval = interval_sets_representation(r'1_carbon_chafen1_1000.csv', interval_len)
    # write_data_interval_csv(r'1_carbon_chafen1_interval1000.csv', data_interval)
    # data_interval = interval_sets_representation(r'2_carbon_chafen2_1000.csv', interval_len)
    # write_data_interval_csv(r'2_carbon_chafen2_1000_interval1000.csv', data_interval)

    # 区间长度为300，csv文件划分区间段
    # data_interval=interval_sets_representation(r'carbon10.csv',interval_len)
    # write_data_interval_csv(r'carbon_interval10_400.csv',data_interval)
    # data_interval = interval_sets_representation(r'lbp1_10.csv', interval_len)
    # write_data_interval_csv(r'lbp1_interval10_400.csv', data_interval)
    # data_interval = interval_sets_representation(r'4_carbon_lbp_second_1000.csv', interval_len)
    # write_data_interval_csv(r'4_carbon_lbp_second_interval1000.csv', data_interval)
    # data_interval = interval_sets_representation(r'chafen1lbp2_10.csv', interval_len)
    # write_data_interval_csv(r'chafen1lbp2_interval10_400.csv', data_interval)
    # data_interval = interval_sets_representation(r'1_carbon_chafen1_1000.csv', interval_len)
    # write_data_interval_csv(r'1_carbon_chafen1_interval1000.csv', data_interval)
    # data_interval = interval_sets_representation(r'2_carbon_chafen2_1000.csv', interval_len)
    # write_data_interval_csv(r'2_carbon_chafen2_1000_interval1000.csv', data_interval)
    #区间长度为95，ECG  训练数据 数据区间构造
    # data_interval = interval_sets_representation(r'ECG/ECG9500_1_train.csv', interval_len)
    # write_data_interval_csv(r'ECG/ECG9500_interval1_95_train.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG9500_lbp_first_1_train.csv', interval_len)
    # write_data_interval_csv(r'ECG/ECG9500_lbp1_interval1_95_train.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG9500_chafen1_second_1_train.csv', interval_len)
    # write_data_interval_csv(r'ECG/ECG9500_chafen1lbp2_interval1_95_train.csv', data_interval)

    #区间长度为160，chfdb_chf02_data1三种类型数据区间构造
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb_chf02_2500_anomaly1_data1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb02_oridata1_interval1_160.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb_chf02_data1_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb02_lbp1data1_interval1_160.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb_chf02_data1_chafen1lbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb02_chafenlbp2data1_interval1_160.csv', data_interval)
    #区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb_chf02_2500_anomaly1_label.csv',interval_len,r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb_chf02_intervallabel160.csv')
    # 看一下原始的区间表示和本文提出的区别
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb_chf02_2500_anomaly1_data1.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb02_oridata1_interval1_canshu0dian5_160.csv',
    #                         data_interval)

    # 区间长度为160，chfdb_chf02_data2三种类型数据区间构造
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb_chf02_2500_anomaly1_data2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb02_oridata2_interval1_160.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb_chf02_data2_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb02_lbp1data2_interval1_160.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb_chf02_data2_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb02_chafenlbp2data2_interval1_160.csv', data_interval)
    #
    # # #区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb_chf02_2500_anomaly1_label.csv',interval_len,r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb_chf02_intervallabel160.csv')

    # 看一下原始的区间表示和本文提出的区别(记得改回去参数)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb_chf02_2500_anomaly1_data2.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb02_oridata2_interval1_150_canshu0dian5_160.csv',data_interval)

    # 区间长度为300，mitdb100_data1三种类型数据区间构造，参数为u
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb100_data1/mitdb100_3600_anomaly1_data1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb100_data1/mitdb100_oridata1_interval1_300.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb100_data1/mitdb100_data1_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb100_data1/mitdb100_lbp1data1_interval1_300.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb100_data1/mitdb100_data1_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb100_data1/mitdb100_chafenlbp2data1_interval1_300.csv', data_interval)
    #
    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/mitdb100_data1/mitdb100_3600_anomaly1_label.csv',interval_len,r'ECG/ECG_datasets/new_prese/mitdb100_data1/mitdb100_intervallabel300.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb100_data1/mitdb100_3600_anomaly1_data1.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb100_data1/mitdb100_oridata1_interval1_canshu0dian5_300.csv',data_interval)

    # 区间长度为320，mitdb100_data2三种类型数据区间构造，参数为u
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_3600_anomaly1_data2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_oridata2_interval1_320.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_data2_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_lbp1data2_interval1_320.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_data2_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_chafenlbp2data2_interval1_320.csv', data_interval)

    # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_3600_anomaly1_label.csv',interval_len,r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_intervallabel320.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/mitdb100_data2/mitdb100_3600_anomaly1_data2.csv',
    #                                              interval_len)
    # write_data_interval_csv(r'ECG/ECG_datasets/mitdb100_data2/mitdb100_oridata2_interval1_300_canshu0dian5.csv',data_interval)

    # 区间长度为210，qtdbsel104_data1三种类型数据区间构造，参数为u
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_2500_anomaly3_data1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_oridata1_interval3_210.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_data1_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_lbp1data1_interval3_210.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_data1_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_chafenlbp2data1_interval3_210.csv', data_interval)

    # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_2500_anomaly3_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_intervallabel210.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_2500_anomaly3_data1.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_oridata1_interval3_210_canshu0dian5.csv',data_interval)

    # 区间长度为200，qtdbsel104_data2三种类型数据区间构造，参数为u
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_2500_anomaly3_data2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_oridata2_interval3_210.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_data2_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_lbp1data2_interval3_210.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_data2_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_chafenlbp2data2_interval3_210.csv', data_interval)

    # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_2500_anomaly3_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_intervallabel210.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_2500_anomaly3_data2.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_oridata2_interval3_canshu0dian5_210.csv',data_interval)

    # 区间长度为200，qtdbsele0126_data1三种类型数据区间构造，参数为u
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_2500_anomaly1_data1.csv', interval_len)
    # write_data_interval_csv(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_oridata1_interval1_200.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_data1_lbp1.csv', interval_len)
    # write_data_interval_csv(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_lbp1data1_interval1_200.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_data1_chafenlbp2.csv', interval_len)
    # write_data_interval_csv(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_chafenlbp2data1_interval1_200.csv', data_interval)
    #
    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_2500_anomaly1_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_intervallabel.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_2500_anomaly1_data1.csv',
    #                                              interval_len)
    # write_data_interval_csv(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_oridata1_interval1_200_canshu0dian5.csv',data_interval)

    # 区间长度为300，mitdb102_data1三种类型数据区间构造，参数为u
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/mitdb102_data1/mitdb102_3600_anomaly1_data1.csv', interval_len)
    # write_data_interval_csv(r'ECG/ECG_datasets/mitdb102_data1/mitdb102_oridata1_interval1_300.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/mitdb102_data1/mitdb102_data1_lbp1.csv', interval_len)
    # write_data_interval_csv(r'ECG/ECG_datasets/mitdb102_data1/mitdb102_lbp1data1_interval1_300.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/mitdb102_data1/mitdb102_data1_chafenlbp2.csv', interval_len)
    # write_data_interval_csv(r'ECG/ECG_datasets/mitdb102_data1/mitdb102_chafenlbp2data1_interval1_300.csv', data_interval)
    # #
    # # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/mitdb102_data1/mitdb102_3600_anomaly1_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/mitdb102_data1/mitdb102_intervallabel.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/mitdb102_data1/mitdb102_3600_anomaly1_data1.csv',
    #                                              interval_len)
    # write_data_interval_csv(r'ECG/ECG_datasets/mitdb102_data1/mitdb102_oridata1_interval1_300_canshu0dian5.csv',data_interval)

    # 区间长度为300，mitdb104_data1三种类型数据区间构造，参数为u
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_3600_anomaly4_data1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_oridata1_interval4_300.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_data1_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_lbp1data1_interval4_300.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_data1_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_chafenlbp2data1_interval4_300.csv', data_interval)
    #
    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_3600_anomaly4_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_intervallabel300.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_3600_anomaly4_data1.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_oridata1_interval4_canshu0dian5_300.csv',
    #                         data_interval)

    # 区间长度为300，mitdb104_data2三种类型数据区间构造，参数为u
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_3600_anomaly4_data2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_oridata2_interval4_300.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_data2_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_lbp1data2_interval4_300.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_data2_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_chafenlbp2data2_interval4_300.csv', data_interval)

    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_3600_anomaly4_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_intervallabel300.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_3600_anomaly4_data2.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_oridata2_interval4_canshu0dian5_300.csv',
    #                         data_interval)

    # 区间长度为250，chfdb01_275_data1三种类型数据区间构造，参数为u,new_prese下
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf01_275_data1/chfdb01_275_3751_anomaly1_data1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf01_275_data1/chfdb01_275_oridata1_interval2_250.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf01_275_data1/chfdb01_275_data1_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf01_275_data1/chfdb01_275_lbp1data1_interval2_250.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf01_275_data1/chfdb01_275_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf01_275_data1/chfdb01_275_chafenlbp2_interval2_250.csv', data_interval)

    # # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/chf01_275_data1/chfdb01_275_3751_anomaly1_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/chf01_275_data1/chf01_275_intervallabel250.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf01_275_data1/chfdb01_275_3751_anomaly1_data1.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf01_275_data1/chf01_275_interval2_250_canshu0dian5.csv',
    #                         data_interval)

    # 区间长度为450，chfdb01_275_data2三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf01_275_data2/chfdb01_275_3751_anomaly1_data2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf01_275_data2/chfdb01_275_oridata2_interval2_450.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf01_275_data2/chfdb01_275_data2_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf01_275_data2/chfdb01_275_lbp1data2_interval2_450.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf01_275_data2/chfdb01_275_data2_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf01_275_data2/chfdb01_275_chafenlbp2_interval2_450.csv', data_interval)
    #
    # # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/chf01_275_data2/chfdb01_275_3751_anomaly1_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/chf01_275_data2/chf01_275_intervallabel450.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf01_275_data2/chfdb01_275_3751_anomaly1_data2.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf01_275_data2/chf01_275_data2_interval2_450_canshu0dian5.csv',
    #                         data_interval)

    # 区间长度为300，chfdb13_3750_data1三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_3750_anomaly1_data1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_oridata1_interval1_300.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_3751_data1_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_3750_lbp1data1_interval1_300.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_3751_data1_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_3750_chafenlbp2_interval1_300.csv', data_interval)
    #
    # # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_3750_anomaly1_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_3750_intervallabel300.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_3750_anomaly1_data1.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_data1_interval1_canshu0dian5_300.csv',
    #                         data_interval)

    # 区间长度为150，chfdb13_3750_data2三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_3750_anomaly1_data2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_oridata2_interval1_150.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_3751_data2_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_3750_lbp1data2_interval1_150.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_3751_data2_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_3750_chafenlbp2_interval1_150.csv', data_interval)
    #
    # # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_3750_anomaly1_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_3750_intervallabel150.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_3750_anomaly1_data2.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_data2_interval1_canshu0dian5_150.csv',
    #                         data_interval)

    # 区间长度为305，mitdb100_108_data1三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_anomaly1_data1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_oridata1_interval1_305.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_data1_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_lbp1data1_interval1_305.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_data1_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_chafenlbp2_interval1_305.csv', data_interval)
    #
    # # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_anomaly1_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_intervallabel305.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_anomaly1_data1.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_interval1_canshu0dian5_305.csv',
    #                         data_interval)

    # 区间长度为600，mitdb100_108_data1三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_anomaly1_data1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_oridata1_interval1_600.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_data1_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_lbp1data1_interval1_600.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_data1_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_chafenlbp2_interval1_600.csv', data_interval)
    #
    # # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_anomaly1_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_intervallabel600.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_anomaly1_data1.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_interval1_canshu0dian5_600.csv',
    #                         data_interval)

    # 区间长度为1200，mitdb100_108_data1三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_anomaly1_data1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_oridata1_interval1_600.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdbx108_x108_15000_data1_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_lbp1data1_interval1_600.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdbx108_x108_15000_data1_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_chafenlbp2_interval1_600.csv', data_interval)

    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_anomaly1_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_intervallabel600.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_anomaly1_data1.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_interval1_canshu0dian5_600.csv',
    #                         data_interval)

    # 区间长度为600，mitdb100_108_data2三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_anomaly1_data2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_oridata2_interval1_600.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdbx108_x108_15000_data2_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_lbp1data2_interval1_600.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdbx108_x108_15000_data2_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_chafenlbp2_interval1_600.csv', data_interval)

    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_anomaly1_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_intervallabel600.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_anomaly1_data2.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_interval1_canshu0dian5_600.csv',
    #                         data_interval)

    # 区间长度为800，qtdbsel102_15000_data1三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_anomaly1_data1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_oridata1_interval1_800.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_data1_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_lbp1data1_interval1_800.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_data1_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_chafenlbp2_interval1_800.csv', data_interval)

    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_anomaly1_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_intervallabel800.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_anomaly1_data1.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_interval1_canshu0dian5_800.csv',
    #                         data_interval)

    # 区间长度为150，qtdbsele0606_1500_data1三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_anomaly1_data1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_oridata1_interval1_150.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_data1_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_lbp1data1_interval1_150.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_data1_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_chafenlbp2_interval1_150.csv', data_interval)

    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_anomaly1_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_intervallabel150.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_anomaly1_data1.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_interval1_canshu0dian5_150.csv',
    #                         data_interval)

    # 区间长度为150，qtdbsele0606_1500_data2三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_anomaly1_data2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_oridata2_interval1_150.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_data2_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_lbp1data2_interval1_150.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_data2_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_chafenlbp2_interval1_150.csv', data_interval)

    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_anomaly1_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_intervallabel150.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_anomaly1_data2.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_interval1_canshu0dian5_150.csv',
    #                         data_interval)

    # 区间长度为160，chf15_3000_data1三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chfdb15_3000_anomaly1_data1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chfdb15_3000_oridata1_interval1_160.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chfdb15_3000_data1_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chfdb15_3000_lbp1data1_interval1_160.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chfdb15_3000_data1_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chf15_3000_chafenlbp2_interval1_160.csv', data_interval)

    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chfdb15_3000_anomaly1_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chf15_3000_intervallabel160.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chfdb15_3000_anomaly1_data1.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chf15_3000_interval1_canshu0dian5_150.csv',
    #                         data_interval)

    # 区间长度为160，chf15_3000_data2三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chfdb15_3000_anomaly1_data2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chfdb15_3000_oridata2_interval1_160.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chfdb15_3000_data2_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chfdb15_3000_lbp1data2_interval1_160.csv', data_interval)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chfdb15_3000_data2_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chf15_3000_chafenlbp2_interval1_160.csv', data_interval)

    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chfdb15_3000_anomaly1_label.csv',
    #                                interval_len,r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chf15_3000_intervallabel160.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chfdb15_3000_anomaly1_data2.csv',
    #                                              interval_len,cluster_num)
    # write_data_interval_csv(r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chf15_3000_interval1_canshu0dian5_160.csv',
    #                         data_interval)

    #video_sur dataset **********************************
    # 区间长度为250，video_sur dataset data1三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'video_sur_dataset/video_sur_data1/video_sur_2000_anomaly_data1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'video_sur_dataset/video_sur_data1/video_sur_2000_oridata1_interval1_150.csv', data_interval)
    # data_interval = interval_sets_representation(r'video_sur_dataset/video_sur_data1/video_sur_2000_data1_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'video_sur_dataset/video_sur_data1/video_sur_2000_lbp1data1_interval1_150.csv', data_interval)
    # data_interval = interval_sets_representation(r'video_sur_dataset/video_sur_data1/video_sur_2000_data1_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'video_sur_dataset/video_sur_data1/video_sur_2000_chafenlbp2_interval1_150.csv', data_interval)

    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'video_sur_dataset/video_sur_data1/video_sur_2000_anomaly_label.csv',
    #                                interval_len,r'video_sur_dataset/video_sur_data1/video_sur_2000_intervallabel150.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(
    #     r'video_sur_dataset/video_sur_data1/video_sur_2000_anomaly_data1.csv',
    #     interval_len, cluster_num)
    # write_data_interval_csv(r'video_sur_dataset/video_sur_data1/video_sur_2000_interval1_canshu0dian5_150.csv',
    #                         data_interval)

    # video_sur dataset **********************************
    # 区间长度为150，video_sur dataset data2三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'video_sur_dataset/video_sur_data2/video_sur_3000_anomaly_data2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'video_sur_dataset/video_sur_data2/video_sur_3000_oridata2_interval1_150.csv', data_interval)
    # data_interval = interval_sets_representation(r'video_sur_dataset/video_sur_data2/video_sur_3000_data2_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'video_sur_dataset/video_sur_data2/video_sur_3000_lbp1data2_interval1_150.csv', data_interval)
    # data_interval = interval_sets_representation(r'video_sur_dataset/video_sur_data2/video_sur_3000_data2_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'video_sur_dataset/video_sur_data2/video_sur_3000_chafenlbp2_interval1_150.csv', data_interval)

    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'video_sur_dataset/video_sur_data2/video_sur_3000_anomaly_label.csv',
    #                                interval_len,r'video_sur_dataset/video_sur_data2/video_sur_3000_intervallabel150.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(
    #     r'video_sur_dataset/video_sur_data2/video_sur_3000_anomaly_data2.csv',
    #     interval_len, cluster_num)
    # write_data_interval_csv(r'video_sur_dataset/video_sur_data2/video_sur_3000_interval1_canshu0dian5_150.csv',
    #                         data_interval)

    # 区间长度为1000，space_shuttle dataset data1三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_tek16_5000_anomaly.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_5000_oridata1_interval1_1000.csv', data_interval)
    # data_interval = interval_sets_representation(r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_5000_data1_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_5000_lbp1data1_interval1_1000.csv', data_interval)
    # data_interval = interval_sets_representation(r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_5000_data1_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_5000_chafenlbp2_interval1_1000.csv', data_interval)

    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_tek16_5000_anomaly_label.csv',
    #                                interval_len,
    #                                r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_5000_intervallabel1000.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(
    #     r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_tek16_5000_anomaly.csv',
    #     interval_len, cluster_num)
    # write_data_interval_csv(r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_5000_interval1_canshu0dian5_1000.csv',
    #                         data_interval)

    # 区间长度为690，powerdemand dataset data1三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'power_demand/power_demand_data/power_demand_5000_anomaly_data1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'power_demand/power_demand_data/power_demand_5000_oridata1_interval1_690.csv', data_interval)
    # data_interval = interval_sets_representation(r'power_demand/power_demand_data/power_demand_5000_data1_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'power_demand/power_demand_data/power_demand_5000_lbp1data1_interval1_690.csv', data_interval)
    # data_interval = interval_sets_representation(r'power_demand/power_demand_data/power_demand_5000_data1_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'power_demand/power_demand_data/power_demand_5000_chafenlbp2_interval1_690.csv', data_interval)

    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'power_demand/power_demand_data/power_demand_5000_anomaly_label.csv',
    #                                interval_len,
    #                                r'power_demand/power_demand_data/power_demand_5000_intervallabel690.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(
    #     r'power_demand/power_demand_data/power_demand_5000_anomaly_data1.csv',
    #     interval_len, cluster_num)
    # write_data_interval_csv(r'power_demand/power_demand_data/power_demand_5000_interval1_canshu0dian5_690.csv',
    #                         data_interval)

    # 区间长度为400，respiration dataset data1三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'respiration_dataset/respiration_data44/respiration6500_anomaly_data1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'respiration_dataset/respiration_data44/respiration6500_oridata1_interval1_400.csv', data_interval)
    # data_interval = interval_sets_representation(r'respiration_dataset/respiration_data44/respiration_6500_data1_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'respiration_dataset/respiration_data44/respiration6500_lbp1data1_interval1_400.csv', data_interval)
    # data_interval = interval_sets_representation(r'respiration_dataset/respiration_data44/respiration_6500_data1_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'respiration_dataset/respiration_data44/respiration6500_chafenlbp2_interval1_400.csv', data_interval)

    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'respiration_dataset/respiration_data44/respiration6500_anomaly_label.csv',
    #                                interval_len,
    #                                r'respiration_dataset/respiration_data44/respiration6500_intervallabel400.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(
    #     r'respiration_dataset/respiration_data44/respiration6500_anomaly_data1.csv',
    #     interval_len, cluster_num)
    # write_data_interval_csv(r'respiration_dataset/respiration_data44/respiration6500_interval1_canshu0dian5_400.csv',
    #                         data_interval)




    # ****************************合成数据测试*****************************
    # 区间长度为60，合成数据三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'comparsion_methods/compare_files/artificial_dataset/artificial_datasets.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'comparsion_methods/compare_files/artificial_dataset/artificial_oridata1_interval1_60.csv', data_interval)
    # data_interval = interval_sets_representation(r'comparsion_methods/compare_files/artificial_dataset/artificial_dataset_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'comparsion_methods/compare_files/artificial_dataset/artificial_lbp1data1_interval1_60.csv', data_interval)
    # data_interval = interval_sets_representation(r'comparsion_methods/compare_files/artificial_dataset/artificial_dataset_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'comparsion_methods/compare_files/artificial_dataset/artificial_chafenlbp2_interval1_60.csv', data_interval)
    #
    # # # 区间标签构造
    # ECG_interval_label_generatecsv(r'comparsion_methods/compare_files/artificial_dataset/artificial_datasets_label.csv',
    #                                interval_len,
    #                                r'comparsion_methods/compare_files/artificial_dataset/artificial_intervallabel60.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(
    #     r'carbon_test/spec-55859-F5907_sp05-058.csv',
    #     interval_len, cluster_num)
    # write_data_interval_csv(r'carbon_test/spec-55859-F5907_sp05-058_interval1_canshu0dian5_400.csv',
    #                         data_interval)

    # ****************************058碳星测试*****************************
    # 区间长度为400，spec-55859-F5907_sp05-058三种类型数据区间构造，参数为u，new_prese下的测试
    # data_interval = interval_sets_representation(r'carbon_test/spec-55859-F5907_sp05-058.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'carbon_test/spec-55859-F5907_sp05-058_oridata1_interval1_200.csv', data_interval)
    # data_interval = interval_sets_representation(r'carbon_test/spec-55859-F5907_sp05-058_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'carbon_test/spec-55859-F5907_sp05-058_lbp1data1_interval1_200.csv', data_interval)
    # data_interval = interval_sets_representation(r'carbon_test/spec-55859-F5907_sp05-058_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'carbon_test/spec-55859-F5907_sp05-058_chafenlbp2_interval1_200.csv', data_interval)

    # # 区间标签构造
    # ECG_interval_label_generatecsv(r'carbon_test/spec-55859-F5907_sp05-058_label.csv',
    #                                interval_len,
    #                                r'carbon_test/spec-55859-F5907_sp05-058_intervallabel200.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(
    #     r'carbon_test/spec-55859-F5907_sp05-058.csv',
    #     interval_len, cluster_num)
    # write_data_interval_csv(r'carbon_test/spec-55859-F5907_sp05-058_interval1_canshu0dian5_400.csv',
    #                         data_interval)

    # ****************************188碳星测试*****************************
    # 区间长度为400，188三种类型数据区间构造，参数为u，new_prese下的测试
    data_interval = interval_sets_representation(r'carbon_test/spec-55862-B6210_sp08-188.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'carbon_test/spec-55862-B6210_sp08-188_oridata1_interval1_210.csv', data_interval)
    # data_interval = interval_sets_representation(r'carbon_test/spec-55862-B6210_sp08-188_lbp1.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'carbon_test/spec-55862-B6210_sp08-188_lbp1data1_interval1_210.csv', data_interval)
    # data_interval = interval_sets_representation(r'carbon_test/spec-55862-B6210_sp08-188_chafenlbp2.csv', interval_len,cluster_num)
    # write_data_interval_csv(r'carbon_test/spec-55862-B6210_sp08-188_chafenlbp2_interval1_210.csv', data_interval)

    # # # 区间标签构造
    # ECG_interval_label_generatecsv(r'carbon_test/spec-55862-B6210_sp08-188_label.csv',
    #                                interval_len,
    #                                r'carbon_test/spec-55862-B6210_sp08-188_intervallabel210.csv')

    # 看一下原始的区间表示和本文提出的区别(还要修改上面的参数，记得改回去参数，参数为α=0.5)
    # data_interval = interval_sets_representation(
    #     r'carbon_test/spec-55859-F5907_sp05-058.csv',
    #     interval_len, cluster_num)
    # write_data_interval_csv(r'carbon_test/spec-55859-F5907_sp05-058_interval1_canshu0dian5_400.csv',
    #                         data_interval)


