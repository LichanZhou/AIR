from collections import Counter
import datetime
import data_generate as dg
import HLDD_generation as Hg
import os
import interval_representation as inte_repre
import detection_nofusion as dete_no
#fits->csv, fits_path+csv_path
starttime = datetime.datetime.now()
# carbon_fits_path=r'../data/carbonfits100/'
# carbon_csv_path= r'../results/carboncsv100/'
# dg.data_gener_union(carbon_fits_path,carbon_csv_path)

ECG_csv_path=r'../data/ECG_csv/'
ECG_label_path=r'../data/ECG_label/'

#lbp12 generation

carbonchafen1_100=r'../results/carbonchafen1_100/'
step=2
carbonFLDD_path=r'../results/carbonFLDD100/'
carbonSLDD_path=r'../results/carbonSLDD100/'
fig_SLDD_path=r'../results/figs_chafen_FLDD_SLDD/'

Hg.first_second_generate(ECG_csv_path,step,carbonchafen1_100,carbonFLDD_path,carbonSLDD_path,fig_SLDD_path)

#interval representation

interval_dir=r'../results/carbon_intervals/'
ori_filenames = os.listdir(ECG_csv_path)
label_ori_dir=r'../data/ECG_label/'
inter_size_begin=100
inter_size_end=200
inter_size_step=100
clu_num=3
#每个文件对应一个标签文件时

carbon_instru=0 #指示向量,表明每个文件的label均不同

ECG_results_file = r'../results/carbon_results_AR_index_reallabel_CI.csv'
for ori_filename in ori_filenames:
    data_name=ori_filename.split('.')[0]
    ori_label_path=label_ori_dir+data_name+'_label.csv'
    ori_path=ECG_csv_path+ori_filename
    carbonFLDD_path_csv=carbonFLDD_path+str(data_name)+'FLDD.csv'
    carbonSLDD_path_csv = carbonSLDD_path + str(data_name) + 'SLDD.csv'
    for inte_size in range(inter_size_begin,inter_size_end+1,inter_size_step):
      ori_inter_path = interval_dir + str(data_name) +'_'+str(inte_size) + 'ori_interval.csv'
      FLDD_inter_path = interval_dir + str(data_name) +'_'+ str(inte_size) + 'FLDD_interval.csv'
      SLDD_inter_path = interval_dir + str(data_name) +'_'+ str(inte_size) + 'SLDD_interval.csv'
      #label标签分别都不一样时
      orilabel_inter_path = interval_dir + str(data_name)+'_'+str(inte_size) + '_labelinterval.csv'


      data_intervals_ori=inte_repre.interval_sets_representation(ori_path, inte_size, clu_num)
      inte_repre.write_data_interval_csv(ori_inter_path,data_intervals_ori)

      data_intervals_lbp1=inte_repre.interval_sets_representation(carbonFLDD_path_csv,inte_size,clu_num)
      inte_repre.write_data_interval_csv(FLDD_inter_path,data_intervals_lbp1)

      data_intervals_lbp2=inte_repre.interval_sets_representation(carbonSLDD_path_csv, inte_size, clu_num)
      inte_repre.write_data_interval_csv(SLDD_inter_path,data_intervals_lbp2)

      #标签区间
      if carbon_instru==1:
         if ori_filename == ori_filenames[0]:
            inte_repre.ECG_interval_label_generatecsv(ori_label_path,inte_size,orilabel_inter_path)
         else:
            pass
      else:
         inte_repre.ECG_interval_label_generatecsv(ori_label_path,inte_size,orilabel_inter_path)
      #对每条数据分别进行不融合检测

      dete_num=1   #初始化最开始要检测的异常段
      with open(orilabel_inter_path,'a+',newline='') as f_num:
         f_num.seek(0)
         label_float=[float(label_string) for label_string in f_num.readlines()[0].split(',')]
         count_label=Counter(label_float)
         dete_num=count_label[-1]
      print('当前检测的数据',ori_inter_path)
      print('当前检测的数据的区间长度为',inte_size)

      ori_simi = dete_no.interval_simi(ori_inter_path)
      lbp1_simi = dete_no.interval_simi(FLDD_inter_path)
      chafenlbp2_simi = dete_no.interval_simi(SLDD_inter_path)
      label_filename = orilabel_inter_path

      # 检测二阶的
      dete_no.detection_nofusion(ori_simi, lbp1_simi, chafenlbp2_simi, label_filename, dete_num, ECG_results_file,
                         ori_path, inte_size,starttime,clu_num)