import csv
import math
import os
import matplotlib.pyplot as plt
import numpy as np
from astropy.io import fits
from sklearn.preprocessing import MinMaxScaler
from tqdm import tqdm
import scipy.interpolate as spi
import cv2
from decimal import Decimal
#读取fits数据,平滑处理为csv文件
def MMS(data):
    return MinMaxScaler().fit_transform(data)
def carbonfits_to_data(path):
    #存储fits文件的文件夹路径
    #path = r'D:\zlc\pycharm_projects\pythonProject\carbonfits1000'
    #构造1000条carbon数据
    #path = r'D:\zlc\pycharm_projects\pythonProject\carbonfits1000'
    filenames = os.listdir(path)
    n=len(filenames)
    data_Y=[]
    for j in tqdm(range(0, n)):
        fig = plt.figure(figsize=(16, 8), dpi=80)
        star = fits.open(os.path.join(path, filenames[j]))
        Y = star[0].data[0]
        #直接读取波长
        X = star[0].data[2]
        #计算波长
        # wave = star[0].header['COEFF0']
        # num = star[0].header['NAXIS1']
        # X = np.arange(wave, wave + num * 0.0001 - 0.00005, 0.0001)
        # X = [math.pow(10, x) for x in X]
        # X = np.array(X)
        # z = star[0].header['Z']
        # X = [(z + 1) * x for x in X]
        # print("计算出来的波长",X)

        #进行3阶样条插值
        ipo = spi.splrep(X, Y, k=3)  # 样本点导入，生成参数

        X = np.arange(3700, 9000, 1)
        Y = spi.splev(X, ipo)

        # 平滑
        Y = cv2.GaussianBlur(src=Y, ksize=(29, 29), sigmaX=5)
        #Y = cv2.medianBlur(np.uint8(Y),3)
        # 归一化
        Y = Y.reshape(-1, 1)
        Y = MMS(Y)
        Y = Y.reshape(1, -1)
        Y = list(np.array(Y).flatten())
        #Y = np.array(Y)
        data_Y.append(Y)
    return data_Y
#list和字符串转化
def yasuo_list_string(l):
    ll = []

    for i in l:
        ifloat = Decimal(i).quantize(Decimal("0.000000000"))
        if ifloat != 1 and ifloat != 0:
            i = str(ifloat)
            while (i[-1] == '0'):
                i = i[0:-1]
            ll.append(i)
        if ifloat == 0:
            ll.append(str(0))

        if ifloat == 1.:
            ll.append(str(1))
    return ll
#比较字符串数组，判断要写入的数据是否已经存在
def compare(a,b):
    lenth = len(a)
    for i in range(0,lenth-1):
        if a[i]!=b[i]:
            return False
    return True
def write_to_csv(filename,data_Y):
    count=0  #计数重新写入了多少条数据
    with open(filename,'a+',newline='') as f:
        f.seek(0)
        data_csv=f.readlines()
        for data_y in data_Y:
            data_y_string = yasuo_list_string(list(map(str,data_y)))
            if data_csv!=[]:
                for i in data_csv:
                    data_y_cp = i.split(',')
                    if compare(data_y_cp, data_y_string):
                        print("This data has existed, not write into csv, pass")
                        break;
                    else:
                        writer=csv.writer(f)
                        writer.writerow(data_y_string)
                        count=count+1
                        break;
            else:
                writer = csv.writer(f)
                writer.writerow(data_y_string)
                count = count + 1
        print("write",count,"new data")

def write_to_csv_union(filename,data_Y):
    count=0  #计数重新写入了多少条数据
    with open(filename,'a+',newline='') as f:
        f.seek(0)
        data_csv=f.readlines()

        data_y_string = yasuo_list_string(list(map(str,data_Y)))
        if data_csv!=[]:
            for i in data_csv:
                data_y_cp = i.split(',')
                if compare(data_y_cp, data_y_string):
                    print("This data has existed, not write into csv, pass")
                    break;
                else:
                    writer=csv.writer(f)
                    writer.writerow(data_y_string)
                    count=count+1
                    break;
        else:
            writer = csv.writer(f)
            writer.writerow(data_y_string)
            count = count + 1
    print("write",count,"new data")
#方便碳星直接测试所有尺寸的检测准确率，供union直接调用使用，与main重复
#参数：所有的fits 所在路径
      #生成的对应csv路径的文件夹
def data_gener_union(fits_path,fits_csv_direc):

    data_Y = carbonfits_to_data(fits_path)  #所有的fits的转为csv的总数据
    filenames = os.listdir(fits_path)
    for i,filename in enumerate(filenames):
        data_name=filename.split('.')[0]
        write_to_csv_union(str(fits_csv_direc)+str(data_name)+'.csv', data_Y[i])
        # print(i)
        # plt.plot(range(len(data_Y[i])), data_Y[i])
    # plt.show()

if __name__ == '__main__':
    #两个参数：读取的fits的路径，写入的csv路径
    # data_Y=carbonfits_to_data(r'D:\zlc\pycharm_projects\pythonProject\starfits1000')

    # data_Y = carbonfits_to_data(r'carbon1')
    # # write_to_csv(r'carbon_test/spec-55859-F5907_sp05-058.csv', data_Y)
    # write_to_csv(r'carbon_test/spec-55862-B6210_sp08-188.csv', data_Y)
    # plt.plot(range(len(data_Y[0])),data_Y[0])
    # plt.show()
    fits_path1=r'carbonfits100'
    # fits_path1=r'carbon1'
    fits_csv_direct=r'carbon_union_files/carbon_union_csv/'
    data_gener_union(fits_path1,fits_csv_direct)




