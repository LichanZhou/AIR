import numpy as np
from scipy.optimize import minimize
import matplotlib.pyplot as plt
import math
import random
import time
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import pairwise_distances_argmin
from sklearn.datasets._samples_generator import make_blobs
import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import MinMaxScaler
#用k-means测试
import interval_representation as inter_repre
#归一化
def MMS(data):
    length = len(data)
    weights = []
    for i in range(length):
        weights.append(float(data[i] / np.sum(data)))
    return weights
def plot_origin_interval(filename):

    with open(filename,'a+',newline='') as f:
        f.seek(0)
        data_csv = f.readlines()
        for data in data_csv:
            Y=np.array(data.split(',')).astype(float)
            plt.plot(Y)
            plt.vlines(500,0.2,0.8,color='r')
            plt.hlines(0.2,0,1000)
            plt.show()

# Generate sample data
def k_means_inerval(Y,num_clusters,interval_len):
    np.random.seed(0)
    batch_size = 45
    centers_all=[]
    resultList=random.sample(range(0,interval_len),num_clusters)
    for i in range(num_clusters):

        centers_all.append(Y[resultList[i]])

    n_clusters=num_clusters
    #手工数据集
    # X, labels_true = make_blobs(n_samples=3000, centers=centers, cluster_std=0.7)

    # plot result
    # fig = plt. figure(figsize=(8,3))
    # fig. subplots_adjust(left=0.02, right=0.98, bottom=0.05, top=0.9)
    # colors=['r', 'g', 'b']

    # original data

    # ax=fig.add_subplot(1,2,1)
    row=len(Y)
    X=range(row)
    data=list(zip(X,Y))
    data=np.array(data)
    # for i in range(row):
    #     ax.plot(data[i,0],data[i,1], 'k', marker='.')

    # ax.set_title('original Data')
    # ax.set_xticks(())
    # ax.set_yticks(())

    # compute clustering with K-Means

    k_means=KMeans(init='k-means++', n_clusters = num_clusters, n_init=10)
    t0=time.time()
    k_means.fit(data)

    t_batch=time.time()-t0

    k_means_cluster_centers=np.sort(k_means.cluster_centers_, axis = 0)
    k_means_labels=pairwise_distances_argmin(data, k_means_cluster_centers)

    #K-means

    # ax = fig.add_subplot(1, 2, 2)

    # for k,col in zip (range(n_clusters), colors):
    #     my_members=k_means_labels==k
    #     cluster_center=k_means_cluster_centers[k]
    #     count=len(data[my_members,0])
    #     ax.plot(data[my_members,0],data[my_members,1],col,marker='.')#将同一类的点表示出来
    #     ax.plot(cluster_center[0], cluster_center[1],col,markeredgecolor='k',marker='o')#单独表示聚类中心
    #
    # ax.set_title('k-means')
    # ax.set_xticks(())
    # ax.set_yticks(())
    # plt.text(-3.5,1.8,'traintime: %2fs\ninertia:%f'%(t_batch,k_means.inertia_))
    #
    # plt.show()
    return math.sqrt(k_means.inertia_)
def calc_cluster_avedis(data_one_tiao,interval_len,cluster_num):  #cluster_num:每段的聚类数都一样

    u=[]
    if (len(data_one_tiao)%interval_len)==0:
        duan_num=range(len(data_one_tiao)//interval_len)  #初始划分的时候一共有多少段
    else:
        duan_num = range(len(data_one_tiao) // interval_len+1)

    for i in duan_num:           #对于每一个固定段，信息粒化
        a=i*interval_len   #开始固定段的起始和结束位置
        b=(i+1)*interval_len-1
        median_a_b=(a+b)/2
        data_origin_reduct=data_one_tiao[a:b+1] #截取每段的数据
        duan_len=len(data_origin_reduct)   #判断是否为最后一段，并用最后的数据进行补足
        print('第',i,'段')
        print('段', data_origin_reduct)
        if duan_len<interval_len:
            for j in range(interval_len-duan_len):
                data_origin_reduct.append(data_origin_reduct[-1])
        data_origin_reduct=list(map(float,data_origin_reduct))

        u.append(k_means_inerval(data_origin_reduct,cluster_num,interval_len))
    u=np.asarray(u).reshape(-1, 1)
    u=MMS(u)   #每个数据的归一化u
    print("查看是否归一化",u)
    return u  #返回的是一条数据的u
if __name__=='__main__':
    #plot_origin_interval(r'carbon1.csv')
    calc_cluster_avedis(r'carbon1.csv',500,3)




