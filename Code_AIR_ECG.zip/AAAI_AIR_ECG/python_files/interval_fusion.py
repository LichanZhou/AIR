import csv

import portion as P
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
# 归一化
def MMS(data):
    length=len(data)
    weights=[]
    for i in range(length):
        weights.append(float(data[i]/np.sum(data)))
    return weights

def intervals_fusion(filename,origin_weight,lbp1_weight,lbp2_weight,origin_interval,lbp1_interval,lbp2_interval):
    #求三种类型的数据的每一段的权重
    intervals_num=len(origin_weight)   #区间个数
    origin_lbp1_lbp2_allintervalweigh_guiyi = []
    data_num=len(origin_interval)   #数据个数
    allinterval_fusion=[]
    for i in range(intervals_num):
        origin_lbp1_lbp2_weigh = []
        oneinterval_fusion = []   #一个段的三种权重放在一个list里面
        origin_lbp1_lbp2_weigh.append(origin_weight[i])
        origin_lbp1_lbp2_weigh.append(lbp1_weight[i])
        origin_lbp1_lbp2_weigh.append(lbp2_weight[i])
        # print('归一化前的第',i,'段权重',origin_lbp1_lbp2_weigh)
        origin_lbp1_lbp2_weigh = np.asarray(origin_lbp1_lbp2_weigh).reshape(-1, 1)
        oneinterval_weight_guiyi=MMS(origin_lbp1_lbp2_weigh)    #归一化三个权重
        origin_lbp1_lbp2_allintervalweigh_guiyi.append(oneinterval_weight_guiyi)
        w1=float(oneinterval_weight_guiyi[0])   #三种类型数据的各自权重
        w2=float(oneinterval_weight_guiyi[1])
        w3=float(oneinterval_weight_guiyi[2])
        print('归一化后的第',i,'段权重', oneinterval_weight_guiyi)
        origin_lbp1_lbp2_allintervalweigh_guiyi[i]
    #利用权重，融合每一段的数据
        for j in range(data_num): #对于每一条数据来说，进行融合
            oneinterval_fusion.append(list(map(lambda x :x[0]*w1+x[1]*w2+x[2]*w3 ,zip(origin_interval[j][i],lbp1_interval[j][i],lbp2_interval[j][i]))))
        allinterval_fusion.append(oneinterval_fusion)

    df = pd.DataFrame(allinterval_fusion)  #将融合后的数据写入csv,开始按照每段的所有数据，需要转置
    df_trans=np.transpose(df)                                #写入没有判断是否重复写入，只是追加写入
    df_trans.to_csv(filename, index=False,mode='a+', sep=',',header=None)
    print('写入数据条数：',len(df_trans))



def interval_similarity(intervals):
    interval_num=len(intervals)  #某一段一共多少条数据
    dis_similar=0
    for i in range(interval_num): #对于每一条数据，计算不相似度
        j=i+1
        while j<interval_num: #避免重复计算，从下一个开始
            interval_inter=P.closed(intervals[i][0],intervals[i][1]) & P.closed(intervals[j][0],intervals[j][1])
            interval_union=P.closed(intervals[i][0],intervals[i][1]) | P.closed(intervals[j][0],intervals[j][1])
            #两两区间计算不相似度和
            # print('看看交集到底是什么样子的空',interval_inter)
            if len(interval_inter)==0:    #没有交集的时候利用，相距的差值来代表不相似度
                    dis_similar = dis_similar + 1
                    j = j + 1
                    continue
            else:
                if interval_inter.upper-interval_inter.lower==0:  #如果交集为0，做除数的情况
                    dis_similar = dis_similar + 1
                    j = j + 1
                    continue

            dis_similar=dis_similar+1-np.abs((interval_inter.upper-interval_inter.lower))/np.abs((interval_union.upper-interval_union.lower))
            j = j + 1
    # 求平均的不相似度作为 该段的整体不相似程度certain_interval_dissimilar
    if interval_num==1:   #如果只有一条数据，无法计算数据之间的相似
        certain_interval_dissimilar=1
    else:
        certain_interval_dissimilar=dis_similar / np.sum(range(interval_num))
    # print('看看不相似度是多少', certain_interval_dissimilar)
    return certain_interval_dissimilar
def weight_calcul(data_origin):
    interval_len=len(data_origin[0])
    certain_total_dissimi=[]
    for i in range(interval_len): #对于某一段区间的数据们
        line_certain_interval=[]
        for line in data_origin:  # line 为每一行数据
            print(i)
            line_certain_interval.append(line[i])  #line_certain_intercal为所有数据的某一段，利用交并思想求不相似度，进而求权重

        # print('所有数据的第',i,'段',line_certain_interval)
        certain_total_dissimi.append(interval_similarity(line_certain_interval))
    return certain_total_dissimi   #每个类型的数据的每一段的权重

def read_interval(filename):
    with open(filename,'a+',newline='') as f:
        f.seek(0)
        intervals=f.readlines()
        intervals_floats=[]
        for interval in intervals:  #intervals：所有行的区间；interval：一条数据的区间
            print(interval)
            b=interval.strip('"').split('","')  #b：一条数据的区间转为列表形式
            interval_float_oneline=[]
            for b1 in b:              #b1一条数据的一个区间
                # print('b1',b1)
                c=b1.strip('"\r\n').strip('[').strip(']').strip('"').split(',')  #一条数据的一个区间的list形式
                data=[float(c1.strip(']"\r\n')) for c1 in c] #data 一条数据的一个区间的数组形式，元素为float
                # print('c',c)
                interval_float_oneline.append(data)
            intervals_floats.append(interval_float_oneline)
    return intervals_floats


if __name__=='__main__':
    #只需要四个参数，融合的三种数据的路径文件，生成的融合数据路径

    #测试两条数据
    # carbondata=read_interval(r'carbon1_interval.csv')
    # origin_weights=weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度',origin_weights)
    # lbp1data=read_interval(r'lbp1_interval.csv')
    # lbp1_weights=weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # lbp2data=read_interval(r'lbp2_interval .csv')
    # lbp2_weights=weight_calcul(lbp2data)
    # print('碳星lbp2的每一段的不相似度', lbp2_weights)
    #
    # intervals_fusion(r'carbon_lbp1_lbp2_intervalfusion1.csv',origin_weights,lbp1_weights,lbp2_weights,carbondata,lbp1data,lbp2data)

    #carbon,lbp1,lbp1lbp2 读区间数，计算权重，融合
    # carbondata=read_interval(r'0_carbon_interval1000.csv')
    # origin_weights=weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度',origin_weights)
    # lbp1data=read_interval(r'3_carbon_lbp_first_interval1000.csv')
    # lbp1_weights=weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # lbp2data=read_interval(r'4_carbon_lbp_second_interval1000.csv')
    # lbp2_weights=weight_calcul(lbp2data)
    # print('碳星lbp2的每一段的不相似度', lbp2_weights)
    #
    # intervals_fusion(r'6_carbon_lbp1_lbp2_intervalfusion1000.csv',origin_weights,lbp1_weights,lbp2_weights,carbondata,lbp1data,lbp2data)

    #carbon,lbp1,chafen1lbp2 读区间数，计算权重，融合
    # carbondata=read_interval(r'0_carbon_interval1000.csv')
    # origin_weights=weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度',origin_weights)
    # lbp1data=read_interval(r'3_carbon_lbp_first_interval1000.csv')
    # lbp1_weights=weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data=read_interval(r'5_carbon_chafen1_lbp_second_interval1000.csv')
    # chafen1lbp2_weights=weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'7_carbon_lbp1_chafen1lbp2_intervalfusion1000.csv',origin_weights,lbp1_weights,chafen1lbp2_weights,carbondata,lbp1data,chafen1lbp2data)
    #区间长度为300，计算区间权重和融合区间数据
    # carbondata = read_interval(r'carbon_interval10_300.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'lbp1_interval10_300.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(r'chafen1lbp2_interval10_300.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'8_carbon_lbp1_chafen1lbp2_intervalfusion10_300.csv', origin_weights, lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)
#区间长度为400，计算区间权重和融合区间数据
    # carbondata = read_interval(r'carbon_interval10_400.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'lbp1_interval10_400.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(r'chafen1lbp2_interval10_400.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'9_carbon_lbp1_chafen1lbp2_intervalfusion10_400.csv', origin_weights, lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)
    #ECG数据，权重，融合
    # carbondata = read_interval(r'ECG/ECG9500_interval1_95.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG9500_lbp1_interval1_95.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(r'ECG/ECG9500_chafen1lbp2_interval1_95.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_lbp1_chafen1lbp2_intervalfusion1_95.csv', origin_weights, lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)
    # ECG  训练数据  数据，权重，融合
    # carbondata = read_interval(r'ECG/ECG9500_interval1_95_train.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG9500_lbp1_interval1_95_train.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(r'ECG/ECG9500_chafen1lbp2_interval1_95_train.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)

    # intervals_fusion(r'ECG/ECG_lbp1_chafen1lbp2_intervalfusion1_95_train.csv', origin_weights, lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # #chf02data1 融合
    # carbondata = read_interval(r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb02_oridata1_interval1_160.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb02_lbp1data1_interval1_160.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(r'ECG/ECG_datasets/new_prese/chf02_data1/chfdb02_chafenlbp2data1_interval1_160.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/new_prese/chf02_data1/chf02_data1_intervalfusion160.csv',origin_weights, lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)
    # chf02data2 融合
    # carbondata = read_interval(r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb02_oridata2_interval1_160.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb02_lbp1data2_interval1_160.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(r'ECG/ECG_datasets/new_prese/chf02_data2/chfdb02_chafenlbp2data2_interval1_160.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/new_prese/chf02_data2/chf02_data2_intervalfusion160.csv', origin_weights, lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # mitdb100data1 融合
    # carbondata = read_interval(r'ECG/ECG_datasets/new_prese/mitdb100_data1/mitdb100_oridata1_interval1_300.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/new_prese/mitdb100_data1/mitdb100_lbp1data1_interval1_300.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(r'ECG/ECG_datasets/new_prese/mitdb100_data1/mitdb100_chafenlbp2data1_interval1_300.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/new_prese/mitdb100_data1/mitdb100_data1_intervalfusion300.csv', origin_weights, lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)


    # mitdb100data2 融合
    # carbondata = read_interval(r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_oridata2_interval1_320.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_lbp1data2_interval1_320.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_chafenlbp2data2_interval1_320.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/new_prese/mitdb100_data2/mitdb100_data2_intervalfusion320.csv', origin_weights, lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)


    # qtdbsel104 data1融合
    # carbondata = read_interval(r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_oridata1_interval3_210.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_lbp1data1_interval3_210.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_chafenlbp2data1_interval3_210.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/new_prese/qtdbsel104_data1/qtdbsel104_data1_intervalfusion210.csv', origin_weights, lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # qtdbsel104 data2融合
    # carbondata = read_interval(r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_oridata2_interval3_210.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_lbp1data2_interval3_210.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_chafenlbp2data2_interval3_210.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/new_prese/qtdbsel104_data2/qtdbsel104_data2_intervalfusion210.csv', origin_weights,
    #                  lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)


    # qtdbsele0126 data1融合
    # carbondata = read_interval(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_oridata1_interval1_200.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_lbp1data1_interval1_200.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_chafenlbp2data1_interval1_200.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/qtdbsele0126_data1/qtdbsele0126_data1_intervalfusion.csv', origin_weights,
    #                  lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # mitdb102 data1融合
    # carbondata = read_interval(r'ECG/ECG_datasets/mitdb102_data1/mitdb102_oridata1_interval1_300.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/mitdb102_data1/mitdb102_lbp1data1_interval1_300.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'ECG/ECG_datasets/mitdb102_data1/mitdb102_chafenlbp2data1_interval1_300.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/mitdb102_data1/mitdb102_data1_intervalfusion.csv', origin_weights,
    #                  lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # mitdb104 data1融合
    # carbondata = read_interval(r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_oridata1_interval4_300.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_lbp1data1_interval4_300.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_chafenlbp2data1_interval4_300.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/new_prese/mitdb104_data1/mitdb104_data1_intervalfusion300.csv', origin_weights,
    #                  lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # mitdb104 data2融合
    # carbondata = read_interval(r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_oridata2_interval4_300.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_lbp1data2_interval4_300.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_chafenlbp2data2_interval4_300.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/new_prese/mitdb104_data2/mitdb104_data2_intervalfusion300.csv', origin_weights,
    #                  lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # chfdb01_275 data1融合
    # carbondata = read_interval(r'ECG/ECG_datasets/new_prese/chf01_275_data1/chfdb01_275_oridata1_interval2_250.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/new_prese/chf01_275_data1/chfdb01_275_lbp1data1_interval2_250.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/chf01_275_data1/chfdb01_275_chafenlbp2_interval2_250.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/new_prese/chf01_275_data1/chf01_275_data1_intervalfusion250.csv', origin_weights,
    #                  lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # chfdb01_275 data2融合  new_prese下的测试
    # carbondata = read_interval(r'ECG/ECG_datasets/new_prese/chf01_275_data2/chfdb01_275_oridata2_interval2_450.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/new_prese/chf01_275_data2/chfdb01_275_lbp1data2_interval2_450.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/chf01_275_data2/chfdb01_275_chafenlbp2_interval2_450.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/new_prese/chf01_275_data2/chf01_275_data2_intervalfusion450.csv', origin_weights,
    #                  lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)


    # # chf13_3750 data1融合  new_prese下的测试
    # carbondata = read_interval(r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_oridata1_interval1_300.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_3750_lbp1data1_interval1_300.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_3750_chafenlbp2_interval1_300.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/new_prese/chf13_3750_data1/chf13_3750_data1_intervalfusion300.csv', origin_weights,
    #                  lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # # chf13_3750 data2融合  new_prese下的测试
    # carbondata = read_interval(r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_oridata2_interval1_150.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_3750_lbp1data2_interval1_150.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_3750_chafenlbp2_interval1_150.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/new_prese/chf13_3750_data2/chf13_3750_data2_intervalfusion150.csv',
    #                  origin_weights,
    #                  lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # # mitdb100_108 data1融合  new_prese下的测试
    # carbondata = read_interval(r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_oridata1_interval1_305.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_lbp1data1_interval1_305.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_chafenlbp2_interval1_305.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/new_prese/mitdb100_108_data1/mitdb100_108_data1_intervalfusion305.csv',
    #                  origin_weights,
    #                  lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # mitdb_x108 data1融合  new_prese下的测试
    # carbondata = read_interval(r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_oridata1_interval1_600.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_lbp1data1_interval1_600.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_chafenlbp2_interval1_600.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/new_prese/mitdb_x108_data1/mitdb_x108_data1_intervalfusion600.csv',
    #                  origin_weights,
    #                  lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # mitdbx108_x108_15000 data1融合  new_prese下的测试
    # carbondata = read_interval(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_oridata1_interval1_600.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_lbp1data1_interval1_600.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_chafenlbp2_interval1_600.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data1/mitdb_x108_x108_15000_data1_intervalfusion600.csv',
    #                  origin_weights,
    #                  lbp1_weights,
    #                  chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # # mitdbx108_x108_15000 data2融合  new_prese下的测试
    # carbondata = read_interval(
    #     r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_oridata2_interval1_600.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_lbp1data2_interval1_600.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_chafenlbp2_interval1_600.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(
    #     r'ECG/ECG_datasets/new_prese/mitdbx108_x108_15000_data2/mitdb_x108_x108_15000_data2_intervalfusion600.csv',
    #     origin_weights,
    #     lbp1_weights,
    #     chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # qtdbsel102_15000 data1融合  new_prese下的测试
    # carbondata = read_interval(
    #     r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_oridata1_interval1_800.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_lbp1data1_interval1_800.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_chafenlbp2_interval1_800.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(
    #     r'ECG/ECG_datasets/new_prese/qtdbsel102_15000_data1/qtdbsel102_15000_data1_intervalfusion800.csv',
    #     origin_weights,
    #     lbp1_weights,
    #     chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # qtdbsele0606_1500 data1融合  new_prese下的测试
    # carbondata = read_interval(
    #     r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_oridata1_interval1_150.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_lbp1data1_interval1_150.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_chafenlbp2_interval1_150.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(
    #     r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data1/qtdbsele0606_1500_data1_intervalfusion150.csv',
    #     origin_weights,
    #     lbp1_weights,
    #     chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # qtdbsele0606_1500 data2融合  new_prese下的测试
    # carbondata = read_interval(
    #     r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_oridata2_interval1_150.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_lbp1data2_interval1_150.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_chafenlbp2_interval1_150.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(
    #     r'ECG/ECG_datasets/new_prese/qtdbsele0606_1500_data2/qtdbsele0606_1500_data2_intervalfusion150.csv',
    #     origin_weights,
    #     lbp1_weights,
    #     chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # chf15_3000 data1融合  new_prese下的测试
    # carbondata = read_interval(
    #     r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chfdb15_3000_oridata1_interval1_160.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chfdb15_3000_lbp1data1_interval1_160.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chf15_3000_chafenlbp2_interval1_160.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)

    # intervals_fusion(
    #     r'ECG/ECG_datasets/new_prese/chf15_3000_data1/chf15_3000_data1_intervalfusion160.csv',
    #     origin_weights,
    #     lbp1_weights,
    #     chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # chf15_3000 data2融合  new_prese下的测试
    # carbondata = read_interval(
    #     r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chfdb15_3000_oridata2_interval1_160.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chfdb15_3000_lbp1data2_interval1_160.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chf15_3000_chafenlbp2_interval1_160.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(
    #     r'ECG/ECG_datasets/new_prese/chf15_3000_data2/chf15_3000_data2_intervalfusion160.csv',
    #     origin_weights,
    #     lbp1_weights,
    #     chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    #video_sur dataset ********************************************************8
    # video_sur dataset data1 融合  new_prese下的测试
    # carbondata = read_interval(
    #     r'video_sur_dataset/video_sur_data1/video_sur_2000_oridata1_interval1_150.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(
    #     r'video_sur_dataset/video_sur_data1/video_sur_2000_lbp1data1_interval1_150.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'video_sur_dataset/video_sur_data1/video_sur_2000_chafenlbp2_interval1_150.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(
    #     r'video_sur_dataset/video_sur_data1/video_sur_2000_data1_intervalfusion150.csv',
    #     origin_weights,
    #     lbp1_weights,
    #     chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # video_sur dataset data2 融合  new_prese下的测试
    # carbondata = read_interval(
    #     r'video_sur_dataset/video_sur_data2/video_sur_3000_oridata2_interval1_150.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(
    #     r'video_sur_dataset/video_sur_data2/video_sur_3000_lbp1data2_interval1_150.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'video_sur_dataset/video_sur_data2/video_sur_3000_chafenlbp2_interval1_150.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(
    #     r'video_sur_dataset/video_sur_data2/video_sur_3000_data2_intervalfusion150.csv',
    #     origin_weights,
    #     lbp1_weights,
    #     chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # space_shuttle dataset data1 融合  new_prese下的测试
    # carbondata = read_interval(
    #     r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_5000_oridata1_interval1_1000.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(
    #     r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_5000_lbp1data1_interval1_1000.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_5000_chafenlbp2_interval1_1000.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(
    #     r'space_shuttle_dataset/space_shuttle_tek16/space_shuttle_data1_intervalfusion1000.csv',
    #     origin_weights,
    #     lbp1_weights,
    #     chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # powerdemand dataset data1 融合  new_prese下的测试
    # carbondata = read_interval(
    #     r'power_demand/power_demand_data/power_demand_5000_oridata1_interval1_690.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(
    #     r'power_demand/power_demand_data/power_demand_5000_lbp1data1_interval1_690.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'power_demand/power_demand_data/power_demand_5000_chafenlbp2_interval1_690.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(
    #     r'power_demand/power_demand_data/power_demand_5000_data1_intervalfusion690.csv',
    #     origin_weights,
    #     lbp1_weights,
    #     chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # respiration dataset data1 融合  new_prese下的测试
    # carbondata = read_interval(
    #     r'respiration_dataset/respiration_data44/respiration6500_oridata1_interval1_400.csv')
    # origin_weights = weight_calcul(carbondata)
    # print('碳星原始数据的每一段的不相似度', origin_weights)
    # lbp1data = read_interval(
    #     r'respiration_dataset/respiration_data44/respiration6500_lbp1data1_interval1_400.csv')
    # lbp1_weights = weight_calcul(lbp1data)
    # print('碳星lbp1的每一段的不相似度', lbp1_weights)
    # chafen1lbp2data = read_interval(
    #     r'respiration_dataset/respiration_data44/respiration6500_chafenlbp2_interval1_400.csv')
    # chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    # print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
    #
    # intervals_fusion(
    #     r'respiration_dataset/respiration_data44/respiration6500_data1_intervalfusion400.csv',
    #     origin_weights,
    #     lbp1_weights,
    #     chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)


 # # 碳星 融合  new_prese下的测试
 #    carbondata = read_interval(
 #        r'carbon_test/spec-55859-F5907_sp05-058_oridata1_interval1_400.csv')
 #    origin_weights = weight_calcul(carbondata)
 #    print('碳星原始数据的每一段的不相似度', origin_weights)
 #    lbp1data = read_interval(
 #        r'carbon_test/spec-55859-F5907_sp05-058_lbp1data1_interval1_400.csv')
 #    lbp1_weights = weight_calcul(lbp1data)
 #    print('碳星lbp1的每一段的不相似度', lbp1_weights)
 #    chafen1lbp2data = read_interval(
 #        r'carbon_test/spec-55859-F5907_sp05-058_chafenlbp2_interval1_400.csv')
 #    chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
 #    print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)
 #
 #    intervals_fusion(
 #        r'carbon_test/spec-55859-F5907_sp05-058_intervalfusion400.csv',
 #        origin_weights,
 #        lbp1_weights,
 #        chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)

    # 合成数据 融合  new_prese下的测试
    carbondata = read_interval(
        r'comparsion_methods/compare_files/artificial_dataset/artificial_oridata1_interval1_60.csv')
    origin_weights = weight_calcul(carbondata)
    print('碳星原始数据的每一段的不相似度', origin_weights)
    lbp1data = read_interval(
        r'comparsion_methods/compare_files/artificial_dataset/artificial_lbp1data1_interval1_60.csv')
    lbp1_weights = weight_calcul(lbp1data)
    print('碳星lbp1的每一段的不相似度', lbp1_weights)
    chafen1lbp2data = read_interval(
        r'comparsion_methods/compare_files/artificial_dataset/artificial_chafenlbp2_interval1_60.csv')
    chafen1lbp2_weights = weight_calcul(chafen1lbp2data)
    print('碳星lbp2的每一段的不相似度', chafen1lbp2_weights)

    intervals_fusion(
        r'comparsion_methods/compare_files/artificial_dataset/artificial_intervalfusion60.csv',
        origin_weights,
        lbp1_weights,
        chafen1lbp2_weights, carbondata, lbp1data, chafen1lbp2data)





















